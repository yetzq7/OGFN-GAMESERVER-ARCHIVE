import { Hono } from "hono";

export default (app: Hono) => {
  app.get("/launcher/api/public/distributionpoints/", (c) =>
    c.json({
      distributions: [
        "https://epicgames-download1.akamaized.net/",
        "https://download.epicgames.com/",
        "https://download2.epicgames.com/",
        "https://download3.epicgames.com/",
        "https://download4.epicgames.com/",
        "https://fastly-download.epicgames.com/",
      ],
    })
  );

  app.get(
    "/launcher/api/public/assets/:platform/:catalogItemId/:appName",
    (c) =>
      c.json({
        appName: c.req.param("appName"),
        labelName: c.req.query("label"),
        buildVersion: `Frostbite-${process.env.VERSION}`,
        catalogItemId: c.req.param("catalogItemId"),
        expires: "9999-12-31T23:59:59.999Z",
        items: {
          MANIFEST: {
            signature: "Frostbite",
            distribution: "https://epicgames-download1.akamaized.net/",
            path: "Builds/Fortnite/Content/CloudDir/RxwT9fhXyJWzLl0WXky5X98eJx9XfQ.manifest",
            additionalDistributions: [],
          },
        },
        assetId: c.req.param("appName"),
      })
  );
};
