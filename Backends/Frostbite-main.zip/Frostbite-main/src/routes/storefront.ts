import { Hono } from "hono";
import fs from "fs";
import { GetVersionInfo, verifyToken } from "../utils/funcs";
import { getItemShop, getItemShopV2 } from "../utils/shop";

export default (app: Hono) => {
  app.get("/fortnite/api/storefront/v2/keychain", (c) => {
    const keychain = JSON.parse(
      fs.readFileSync("./static/shop/keychain.json", "utf-8")
    );
    return c.json(keychain);
  });

  app.get("/fortnite/api/storefront/v2/catalog", verifyToken, async (c) => {
    const version = GetVersionInfo(c.req);
    let shopData;

    if (version.build >= 14.3) {
      shopData = await getItemShopV2();
    } else {
      shopData = getItemShop();
    }
    return c.json(shopData);
  });

  app.get("/catalog/api/shared/bulk/offers", (c) => c.json({}));
};
