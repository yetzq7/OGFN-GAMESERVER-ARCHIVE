import { Hono } from "hono";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import { verifyToken } from "../utils/funcs";
import { Logger } from "../utils/logger";

export default (app: Hono) => {
  app.get("/fortnite/api/cloudstorage/system", (c) => {
    const csDir = path.join(__dirname, "../../static/CloudStorage");
    let csFiles: any[] = [];

    fs.readdirSync(csDir).forEach((name) => {
      const fullPath = path.join(csDir, name);
      const stats = fs.statSync(fullPath);

      if (!name.toLowerCase().endsWith(".ini")) return;

      const file = fs.readFileSync(fullPath, "latin1");

      csFiles.push({
        uniqueFilename: name,
        filename: name,
        hash: crypto.createHash("sha1").update(file).digest("hex"),
        hash256: crypto.createHash("sha256").update(file).digest("hex"),
        length: Buffer.byteLength(file),
        contentType: "application/octet-stream",
        uploaded: stats.mtime,
        storageType: "S3",
        storageIds: {},
        doNotCache: true,
      });
    });

    return c.json(csFiles);
  });

  app.get("/fortnite/api/cloudstorage/system/config", (c) => {
    const csDir = path.join(__dirname, "../../static/CloudStorage");
    let csFiles: any[] = [];

    fs.readdirSync(csDir).forEach((name) => {
      const fullPath = path.join(csDir, name);
      const stats = fs.statSync(fullPath);

      if (!name.toLowerCase().endsWith(".ini")) return;

      const file = fs.readFileSync(fullPath, "latin1");

      csFiles.push({
        uniqueFilename: name,
        filename: name,
        hash: crypto.createHash("sha1").update(file).digest("hex"),
        hash256: crypto.createHash("sha256").update(file).digest("hex"),
        length: Buffer.byteLength(file),
        contentType: "application/octet-stream",
        uploaded: stats.mtime,
        storageType: "S3",
        storageIds: {},
        doNotCache: true,
      });
    });

    return c.json(csFiles);
  });

  app.get("/fortnite/api/cloudstorage/system/:file", (c) => {
    const filePath = path.join(
      __dirname,
      "../../static/CloudStorage",
      c.req.param("file")
    );
    try {
      const file = fs.readFileSync(filePath, { encoding: "utf8" });
      return c.text(file);
    } catch {
      return c.text("File not found", 404);
    }
  });

  app.get("/fortnite/api/cloudstorage/user/:accountId", verifyToken, (c) => {
    const accountId = c.req.param("accountId");

    try {
      const clientPath = path.join(
        __dirname,
        "../../static/ClientSettings/",
        accountId
      );
      if (!fs.existsSync(clientPath))
        fs.mkdirSync(clientPath, { recursive: true });

      let csFiles: any[] = [];

      fs.readdirSync(clientPath).forEach((name) => {
        if (!name.toLowerCase().includes("clientsettings")) return;

        const filePath = path.join(clientPath, name);
        const ParsedFile = fs.readFileSync(filePath, "latin1");
        const ParsedStats = fs.statSync(filePath);

        csFiles.push({
          uniqueFilename: name,
          filename: name,
          hash: crypto.createHash("sha1").update(ParsedFile).digest("hex"),
          hash256: crypto.createHash("sha256").update(ParsedFile).digest("hex"),
          length: Buffer.byteLength(ParsedFile),
          contentType: "application/octet-stream",
          uploaded: ParsedStats.mtime,
          storageType: "S3",
          storageIds: {},
          accountId: accountId,
          doNotCache: false,
        });
      });

      return c.json(csFiles);
    } catch (err) {
      Logger.Error("Error /fortnite/api/cloudstorage/user/:accountId: ", err);
      return c.text("Internal Server Error", 500);
    }
  });

  app.put(
    "/fortnite/api/cloudstorage/user/:accountId/:file",
    verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const fileParam = c.req.param("file");

      try {
        const clientPath = path.join(
          __dirname,
          "../../static/ClientSettings/",
          accountId
        );
        if (!fs.existsSync(clientPath))
          fs.mkdirSync(clientPath, { recursive: true });

        if (!fileParam.toLowerCase().includes("clientsettings"))
          return c.text("File is not a valid ClientSettings file", 400);

        const filePath = path.join(clientPath, fileParam);
        const body = await c.req.arrayBuffer();
        fs.writeFileSync(filePath, Buffer.from(body), "latin1");

        return c.json([]);
      } catch (err) {
        Logger.Error(
          "Error /fortnite/api/cloudstorage/user/:accountId/:file: ",
          err
        );
        return c.text("Internal Server Error", 500);
      }
    }
  );

  app.get(
    "/fortnite/api/cloudstorage/user/:accountId/:file",
    verifyToken,
    (c) => {
      const accountId = c.req.param("accountId");
      const fileParam = c.req.param("file");

      const clientPath = path.join(
        __dirname,
        "../../static/ClientSettings/",
        accountId
      );
      if (!fs.existsSync(clientPath))
        fs.mkdirSync(clientPath, { recursive: true });

      if (!fileParam.toLowerCase().includes("clientsettings"))
        return c.json([]);

      const filePath = path.join(clientPath, fileParam);
      if (fs.existsSync(filePath))
        return c.body(fs.readFileSync(filePath) as any);

      return c.json([]);
    }
  );
};
