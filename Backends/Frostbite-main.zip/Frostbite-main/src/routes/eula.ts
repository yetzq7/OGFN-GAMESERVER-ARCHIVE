import { Hono } from "hono";
import User, { type IUser } from "../database/models/user";
import { verifyToken } from "../utils/funcs";
import * as error from "../utils/error";
import eulaJson from "../../static/responses/EULA.json" assert { type: "json" };

export default (app: Hono) => {
  app.get("/eulatracking/api/shared/agreements/*", (c) => c.json(eulaJson));

  app.get(
    "/eulatracking/api/public/agreements/:platform/account/:accountId",
    verifyToken,
    async (c) => {
      const user = await User.findOne({
        accountId: c.req.param("accountId"),
      }).lean<IUser>();
      if (!user) return c.status(400);

      if (!user.acceptedEULA) {
        return c.json(eulaJson);
      } else {
        return c.body(null, 204);
      }
    }
  );

  app.post(
    "/eulatracking/api/public/agreements/:platform/version/:version/account/:accountId/accept",
    verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      if (!accountId) return c.status(400);

      const user = await User.findOne({ accountId });
      if (!user)
        return error.createError(
          c,
          "errors.com.epicgames.account.account_not_found",
          `Sorry we couldn"t find an account for ${accountId}`,
          [accountId],
          18007,
          undefined,
          404
        );

      if (!user.acceptedEULA) {
        user.acceptedEULA = true;
        await user.save();
      }

      return c.body(null, 204);
    }
  );
};
