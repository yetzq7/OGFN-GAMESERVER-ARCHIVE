import { Hono } from "hono";
import { MakeID, verifyToken } from "../utils/funcs";
import * as error from "../utils/error";
import { type ITokenStore, TokenStore } from "../database/models/tokens";
import axios from "axios";
import { Logger } from "../utils/logger";
const parties: Record<string, any> = {};
const pings: any[] = [];

export default (app: Hono) => {
  app.post("/party/api/v1/Fortnite/parties/*", verifyToken, async (c) => {
    const body = await c.req.json();
    const joinInfo = body?.join_info;

    if (!joinInfo?.connection) return c.json({});

    const { connection, meta: joinMeta } = joinInfo;
    const accountId = (connection.id || "").split("@prod")[0];
    const now = new Date().toISOString();
    const partyId = MakeID();

    const member = {
      account_id: accountId,
      meta: joinMeta || {},
      connections: [
        {
          id: connection.id || "",
          connected_at: now,
          updated_at: now,
          yield_leadership: connection.yield_leadership || false,
          meta: connection.meta || {},
        },
      ],
      revision: 0,
      updated_at: now,
      joined_at: now,
      role: "CAPTAIN",
    };

    const party = {
      id: partyId,
      created_at: now,
      updated_at: now,
      config: body.config,
      members: [member],
      applicants: [],
      meta: body.meta || {},
      invites: [],
      revision: 0,
      intentions: [],
    };

    parties[partyId] = party;

    return c.json(party);
  });

  app.get("/party/api/v1/Fortnite/user/:accountId", verifyToken, (c) => {
    const accountId = c.req.param("accountId");

    const matchedParties = Object.values(parties).filter((party) =>
      party.members.some((member: any) => member.account_id === accountId)
    );

    return c.json({
      current: matchedParties,
      pending: [],
      invites: [],
      pings: pings.filter((party) => party.id === accountId),
    });
  });

  app.get(
    "/party/api/v1/Fortnite/user/:accountId/notifications/undelivered/count",
    verifyToken,
    async (c) => {
      const { accountId } = c.req.param();

      const party = Object.values(parties).find((party) =>
        party.members.some((member: any) => member.account_id === accountId)
      );

      return c.json({
        pings: pings.filter((party) => party.id === accountId).length,
        invites: party
          ? party.invites.filter((invite: any) => invite.sent_to === accountId)
              .length
          : 0,
      });
    }
  );

  app.patch(
    "/party/api/v1/Fortnite/parties/:partyid",
    verifyToken,
    async (c) => {
      const partyid = c.req.param("partyid");
      const party = parties[partyid];

      if (!party) {
        return error.createError(
          c,
          "errors.com.epicgames.party.not_found",
          `Party ${partyid} does not exist!`,
          [],
          51002,
          undefined,
          404
        );
      }

      const authHeader = c.req.header("authorization");
      const token = authHeader!.slice("bearer ".length);
      const store = await TokenStore.findOne({
        accessToken: token,
      }).lean<ITokenStore>();
      const accountId = store?.accountId;
      const editingMember = party.members.find(
        (member: any) => member.account_id === accountId
      );

      if (editingMember && editingMember.role !== "CAPTAIN") {
        return error.createError(
          c,
          "errors.com.epicgames.party.unauthorized",
          `User ${accountId} is not allowed to edit party ${partyid}!`,
          [],
          51015,
          undefined,
          403
        );
      }

      const body = await c.req.json();

      if (body.config) {
        for (const key of Object.keys(body.config)) {
          party.config[key] = body.config[key];
        }
      }

      if (body.meta) {
        if (Array.isArray(body.meta.delete)) {
          for (const key of body.meta.delete) {
            delete party.meta[key];
          }
        }

        if (body.meta.update && typeof body.meta.update === "object") {
          for (const key of Object.keys(body.meta.update)) {
            party.meta[key] = body.meta.update[key];
          }
        }
      }

      party.revision = body.revision;
      party.updated_at = new Date().toISOString();
      parties[partyid] = party;

      const captain = party.members.find(
        (member: any) => member.role === "CAPTAIN"
      );

      await Promise.all(
        party.members.map(async (member: any) => {
          try {
            await axios.post(
              `http://localhost:80/api/voryn/message/send/${member.account_id}`,
              {
                captain_id: captain?.account_id,
                created_at: party.created_at,
                invite_ttl_seconds: 14400,
                max_number_of_members: party.config.max_size,
                ns: "Fortnite",
                party_id: party.id,
                party_privacy_type: party.config.joinability,
                party_state_overriden: {},
                party_state_removed: body.meta?.delete || [],
                party_state_updated: body.meta?.update || {},
                party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
                party_type: "DEFAULT",
                revision: party.revision,
                sent: new Date().toISOString(),
                type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                updated_at: new Date().toISOString(),
              }
            );
          } catch (err: any) {
            Logger.Error(
              `Failed to send to ${member.account_id}:`,
              err.message
            );
          }
        })
      );

      return c.body(null, 204);
    }
  );

  app.patch(
    "/party/api/v1/Fortnite/parties/:partyid/members/:accountId/meta",
    verifyToken,
    async (c) => {
      const partyid = c.req.param("partyid");
      const targetAccountId = c.req.param("accountId");
      const party = parties[partyid];

      if (!party) {
        return error.createError(
          c,
          "errors.com.epicgames.party.not_found",
          `Party ${partyid} does not exist!`,
          [],
          51002,
          undefined,
          404
        );
      }

      const authHeader = c.req.header("authorization");
      const token = authHeader!.slice("bearer ".length);
      const store = await TokenStore.findOne({
        accessToken: token,
      }).lean<ITokenStore>();
      const accountId = store?.accountId;

      if (accountId !== targetAccountId) {
        return error.createError(
          c,
          "errors.com.epicgames.party.unauthorized",
          `User ${accountId} is not allowed to edit member ${targetAccountId}!`,
          [],
          51015,
          undefined,
          403
        );
      }

      const memberIndex = party.members.findIndex(
        (m: any) => m.account_id === targetAccountId
      );
      if (memberIndex === -1) {
        return c.body(null, 403);
      }

      const member = party.members[memberIndex];
      const body = await c.req.json();

      if (body.delete && typeof body.delete === "object") {
        for (const key of Object.keys(body.delete)) {
          delete member.meta[key];
        }
      }

      if (body.update && typeof body.update === "object") {
        for (const key of Object.keys(body.update)) {
          member.meta[key] = body.update[key];
        }
      }

      member.revision = body.revision;
      member.updated_at = new Date().toISOString();
      party.members[memberIndex] = member;
      party.updated_at = new Date().toISOString();
      parties[partyid] = party;

      await Promise.all(
        party.members.map(async (m: any) => {
          try {
            await axios.post(
              `http://localhost:80/api/voryn/message/send/${m.account_id}`,
              {
                account_id: targetAccountId,
                account_dn: member.meta["urn:epic:member:dn_s"],
                member_state_updated: body.update || {},
                member_state_removed: body.delete || {},
                member_state_overridden: {},
                party_id: party.id,
                updated_at: new Date().toISOString(),
                sent: new Date().toISOString(),
                revision: member.revision,
                ns: "Fortnite",
                type: "com.epicgames.social.party.notification.v0.MEMBER_STATE_UPDATED",
              }
            );
          } catch (err: any) {
            Logger.Error(`Failed to send to ${m.account_id}:`, err.message);
          }
        })
      );

      return c.body(null, 204);
    }
  );

  app.post(
    "/party/api/v1/Fortnite/parties/:partyId/members/:accountId/join",
    verifyToken,
    async (c) => {
      const partyId = c.req.param("partyId");
      const accountId = c.req.param("accountId");
      const body = await c.req.json();
      const party = parties[partyId];

      if (!party) {
        return error.createError(
          c,
          "errors.com.epicgames.party.not_found",
          `Party ${partyId} does not exist!`,
          [],
          51002,
          undefined,
          404
        );
      }

      const alreadyMember = party.members.find(
        (m: any) => m.account_id === accountId
      );
      if (alreadyMember) {
        return c.json({
          status: "JOINED",
          party_id: party.id,
        });
      }

      const connId = (body.connection?.id || "").split("@prod")[0];

      const mem = {
        account_id: connId,
        meta: body.meta || {},
        connections: [
          {
            id: body.connection?.id || "",
            connected_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            yield_leadership: !!body.connection?.yield_leadership,
            meta: body.connection?.meta || {},
          },
        ],
        revision: 0,
        updated_at: new Date().toISOString(),
        joined_at: new Date().toISOString(),
        role: body.connection?.yield_leadership ? "CAPTAIN" : "MEMBER",
      };

      party.members.push(mem);

      const metaKey = party.meta["Default:RawSquadAssignments_j"]
        ? "Default:RawSquadAssignments_j"
        : "RawSquadAssignments_j";
      let rsa: any = null;

      if (party.meta[metaKey]) {
        rsa = JSON.parse(party.meta[metaKey]);
        rsa.RawSquadAssignments.push({
          memberId: connId,
          absoluteMemberIdx: party.members.length - 1,
        });
        party.meta[metaKey] = JSON.stringify(rsa);
        party.revision++;
      }

      party.updated_at = new Date().toISOString();
      parties[partyId] = party;

      const captain = party.members.find((m: any) => m.role === "CAPTAIN") || {
        account_id: "",
      };

      c.status(200);
      c.json({
        status: "JOINED",
        party_id: party.id,
      });

      for (const member of party.members) {
        try {
          await axios.post(
            `http://localhost:80/api/voryn/message/send/${member.account_id}`,
            {
              account_dn: body.connection?.meta?.["urn:epic:member:dn_s"],
              account_id: connId,
              connection: {
                connected_at: new Date().toISOString(),
                id: body.connection?.id,
                meta: body.connection?.meta,
                updated_at: new Date().toISOString(),
              },
              joined_at: new Date().toISOString(),
              member_state_updated: body.meta || {},
              ns: "Fortnite",
              party_id: party.id,
              revision: 0,
              sent: new Date().toISOString(),
              type: "com.epicgames.social.party.notification.v0.MEMBER_JOINED",
              updated_at: new Date().toISOString(),
            }
          );
        } catch (err: any) {
          Logger.Error(
            `Failed to send MEMBER_JOINED to ${member.account_id}:`,
            err.message
          );
        }

        if (rsa) {
          try {
            await axios.post(
              `http://localhost:80/api/voryn/message/send/${member.account_id}`,
              {
                captain_id: captain.account_id,
                created_at: party.created_at,
                invite_ttl_seconds: 14400,
                max_number_of_members: party.config.max_size,
                ns: "Fortnite",
                party_id: party.id,
                party_privacy_type: party.config.joinability,
                party_state_overriden: {},
                party_state_removed: [],
                party_state_updated: {
                  [metaKey]: JSON.stringify(rsa),
                },
                party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
                party_type: "DEFAULT",
                revision: party.revision,
                sent: new Date().toISOString(),
                type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                updated_at: new Date().toISOString(),
              }
            );
          } catch (err: any) {
            Logger.Error(
              `Failed to send PARTY_UPDATED to ${member.account_id}:`,
              err.message
            );
          }
        }
      }

      return c.body(null);
    }
  );

  app.delete(
    "/party/api/v1/Fortnite/parties/:partyId/members/:accountId",
    verifyToken,
    async (c) => {
      const partyId = c.req.param("partyId");
      const targetAccountId = c.req.param("accountId");
      const authHeader = c.req.header("authorization");
      const token = authHeader!.slice("bearer ".length);

      const store = await TokenStore.findOne({
        accessToken: token,
      }).lean<ITokenStore>();
      const accountId = store?.accountId;

      const party = parties[partyId];
      if (!party) {
        return error.createError(
          c,
          "errors.com.epicgames.party.not_found",
          `Party ${partyId} does not exist!`,
          [],
          51002,
          undefined,
          404
        );
      }

      const memberIndex = party.members.findIndex(
        (m: any) => m.account_id === targetAccountId
      );
      if (memberIndex === -1) {
        return error.createError(
          c,
          "errors.com.epicgames.party.member_not_found",
          `Member ${targetAccountId} not found in party ${partyId}.`,
          [],
          51003,
          undefined,
          404
        );
      }

      const member = party.members[memberIndex];
      if (accountId !== targetAccountId && member.role !== "CAPTAIN") {
        return error.createError(
          c,
          "errors.com.epicgames.party.unauthorized",
          `User ${accountId} is not allowed to delete member ${targetAccountId}!`,
          [],
          51015,
          undefined,
          403
        );
      }

      await Promise.all(
        party.members.map(async (m: any) => {
          try {
            await axios.post(
              `http://localhost:80/api/voryn/message/send/${m.account_id}`,
              {
                account_id: targetAccountId,
                member_state_update: {},
                ns: "Fortnite",
                party_id: party.id,
                revision: party.revision || 0,
                sent: new Date().toISOString(),
                type: "com.epicgames.social.party.notification.v0.MEMBER_LEFT",
              }
            );
          } catch (err: any) {
            Logger.Error(
              `Failed to send MEMBER_LEFT to ${m.account_id}:`,
              err.message
            );
          }
        })
      );

      party.members.splice(memberIndex, 1);

      if (party.members.length === 0) {
        delete parties[partyId];
        return c.body(null, 204);
      }

      const metaKey = party.meta["Default:RawSquadAssignments_j"]
        ? "Default:RawSquadAssignments_j"
        : "RawSquadAssignments_j";

      if (party.meta[metaKey]) {
        const rsa = JSON.parse(party.meta[metaKey]);
        const rsaIndex = rsa.RawSquadAssignments.findIndex(
          (a: any) => a.memberId === targetAccountId
        );
        if (rsaIndex !== -1) {
          rsa.RawSquadAssignments.splice(rsaIndex, 1);
        }

        party.meta[metaKey] = JSON.stringify(rsa);

        let captain = party.members.find((m: any) => m.role === "CAPTAIN");
        if (!captain && party.members.length > 0) {
          party.members[0].role = "CAPTAIN";
          captain = party.members[0];
        }

        party.updated_at = new Date().toISOString();
        parties[partyId] = party;

        await Promise.all(
          party.members.map(async (m: any) => {
            try {
              await axios.post(
                `http://localhost:80/api/voryn/message/send/${m.account_id}`,
                {
                  captain_id: captain.account_id,
                  created_at: party.created_at,
                  invite_ttl_seconds: 14400,
                  max_number_of_members: 16,
                  ns: "Fortnite",
                  party_id: party.id,
                  party_privacy_type: party.config.joinability,
                  party_state_overriden: {},
                  party_state_removed: [],
                  party_state_updated: {
                    [metaKey]: JSON.stringify(rsa),
                  },
                  party_sub_type: party.meta["urn:epic:cfg:party-type-id_s"],
                  party_type: "DEFAULT",
                  revision: party.revision,
                  sent: new Date().toISOString(),
                  type: "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                  updated_at: new Date().toISOString(),
                }
              );
            } catch (err: any) {
              Logger.Error(
                `Failed to send PARTY_UPDATED to ${m.account_id}:`,
                err.message
              );
            }
          })
        );
      }

      return c.body(null, 204);
    }
  );
};
