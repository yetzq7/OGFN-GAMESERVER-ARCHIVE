import { Hono } from "hono";

export default (app: Hono) => {
  app.post("/api/v1/assets/Fortnite/*", async (c) => {
    const body = await c.req.json();
    const assets = {
      FortCreativeDiscoverySurface: {
        meta: {
          promotion: 1,
        },
        assets: {
          CreativeDiscoverySurface_Frontend: {
            meta: {
              revision: 1,
              headRevision: 1,
              revisedAt: "2022-04-11T16:34:03.517Z",
              promotion: 1,
              promotedAt: "2022-04-11T16:34:49.510Z",
            },
            assetData: {
              AnalyticsId: "t412",
              TestCohorts: [
                {
                  AnalyticsId: "c522715413",
                  CohortSelector: "PlayerDeterministic",
                  PlatformBlacklist: [],
                  ContentPanels: [
                    {
                      NumPages: 1,
                      AnalyticsId: "p536",
                      PanelType: "AnalyticsList",
                      AnalyticsListName: "ByEpicWoven",
                      CuratedListOfLinkCodes: [],
                      ModelName: "",
                      PageSize: 7,
                      PlatformBlacklist: [],
                      PanelName: "ByEpicWoven",
                      MetricInterval: "",
                      SkippedEntriesCount: 0,
                      SkippedEntriesPercent: 0,
                      SplicedEntries: [],
                      PlatformWhitelist: [],
                      EntrySkippingMethod: "None",
                      PanelDisplayName: {
                        Category: "Game",
                        NativeCulture: "",
                        Namespace: "CreativeDiscoverySurface_Frontend",
                        LocalizedStrings: [
                          {
                            key: "ar",
                            value: "العب بأسلوبك",
                          },
                          {
                            key: "de",
                            value: "Spiele auf deine Weise",
                          },
                          {
                            key: "en",
                            value: "Play Your Way",
                          },
                          {
                            key: "es",
                            value: "Juega como quieras",
                          },
                          {
                            key: "fr",
                            value: "Jouez à votre façon",
                          },
                          {
                            key: "it",
                            value: "Gioca a modo tuo",
                          },
                          {
                            key: "ja",
                            value: "好きにプレイしよう",
                          },
                          {
                            key: "ko",
                            value: "나만의 플레이",
                          },
                          {
                            key: "pl",
                            value: "Graj po swojemu",
                          },
                          {
                            key: "ru",
                            value: "Играйте как нравится",
                          },
                          {
                            key: "tr",
                            value: "İstediğin Gibi Oyna",
                          },
                          {
                            key: "pt-BR",
                            value: "Jogue do Seu Jeito",
                          },
                          {
                            key: "es-419",
                            value: "Juega a tu manera",
                          },
                        ],
                        bIsMinimalPatch: false,
                        NativeString: "Play Your Way",
                        Key: "ByEpicWoven",
                      },
                      PlayHistoryType: "RecentlyPlayed",
                      bLowestToHighest: false,
                      PanelLinkCodeBlacklist: [],
                      PanelLinkCodeWhitelist: [],
                      FeatureTags: [],
                      MetricName: "",
                    },
                  ],
                  PlatformWhitelist: [],
                  SelectionChance: 0.1,
                  TestName: "Venture",
                },
              ],
              GlobalLinkCodeBlacklist: [],
              SurfaceName: "CreativeDiscoverySurface_Frontend",
              TestName: "20.10_4/11/2022_hero_combat_popularConsole",
              primaryAssetId:
                "FortCreativeDiscoverySurface:CreativeDiscoverySurface_Frontend",
              GlobalLinkCodeWhitelist: [],
            },
          },
        },
      },
    };

    const hasDiscovery = Object.prototype.hasOwnProperty.call(
      body,
      "FortCreativeDiscoverySurface"
    );

    if (hasDiscovery && body.FortCreativeDiscoverySurface === 0) {
      return c.json(assets);
    }

    return c.json({
      FortCreativeDiscoverySurface: {
        meta: {
          promotion: body.FortCreativeDiscoverySurface || 0,
        },
        assets: {},
      },
    });
  });
};
