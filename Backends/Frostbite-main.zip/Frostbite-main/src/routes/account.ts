import { Hono } from "hono";
import User, { type IUser } from "../database/models/user";
import { Logger } from "../utils/logger";
import { verifyToken } from "../utils/funcs";
import * as error from "../utils/error";

export default (app: Hono) => {
  app.get("/account/api/public/account", verifyToken, async (c) => {
    const accountId = c.req.query("accountId");
    if (!accountId) return c.status(400);

    try {
      if (typeof accountId === "string") {
        const user = await User.findOne({
          accountId,
          banned: false,
        }).lean<IUser>();

        if (!user) {
          return error.createError(
            c,
            "errors.com.epicgames.account.account_not_found",
            `Sorry we couldn't find an account for ${accountId}`,
            [accountId],
            18007,
            undefined,
            404
          );
        }

        return c.json([
          {
            id: user.accountId,
            displayName: user.username,
            externalAuths: {},
          },
        ]);
      }

      if (Array.isArray(accountId)) {
        const users = await User.find({
          accountId: { $in: accountId },
          banned: false,
        })
          .limit(100)
          .lean<IUser[]>();

        const response = users.map((user) => ({
          id: user.accountId,
          displayName: user.username,
          externalAuths: {},
        }));

        return c.json(response);
      }
    } catch (err) {
      Logger.Error("Error in /account/api/public/account endpoint: ", err);
      return c.status(500);
    }
  });

  app.get(
    "/account/api/public/account/displayName/:username",
    verifyToken,
    async (c) => {
      const username = c.req.param("username");
      if (!username) return c.status(400);

      try {
        const user = await User.findOne({
          username,
          banned: false,
          isServer: false,
        }).lean<IUser>();
        if (!user)
          return error.createError(
            c,
            "errors.com.epicgames.account.account_not_found",
            `Sorry we couldn"t find an account for ${username}`,
            [username],
            18007,
            undefined,
            404
          );

        return c.json({
          id: user.accountId,
          displayName: username,
          externalAuths: {},
        });
      } catch (err) {
        Logger.Error(
          "Error in /account/api/public/account/displayName/:username endpoint: ",
          err
        );
        return c.status(500);
      }
    }
  );

  app.get("/account/api/public/account/:accountId", verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    if (!accountId) return c.status(400);

    try {
      const user = await User.findOne({
        accountId,
        banned: false,
      }).lean<IUser>();
      if (!user)
        return error.createError(
          c,
          "errors.com.epicgames.account.account_not_found",
          `Sorry we couldn"t find an account for ${accountId}`,
          [accountId],
          18007,
          undefined,
          404
        );

      return c.json({
        id: accountId,
        displayName: user.username,
        name: user.username,
        email: user.email,
        failedLoginAttempts: 0,
        lastLogin: new Date().toISOString(),
        numberOfDisplayNameChanges: 0,
        ageGroup: "UNKNOWN",
        headless: false,
        country: "MA",
        lastName: user.username,
        preferredLanguage: "en",
        canUpdateDisplayName: false,
        tfaEnabled: false,
        emailVerified: true,
        minorVerified: false,
        minorExpected: false,
        minorStatus: "NOT_MINOR",
        cabinedMode: false,
        hasHashedEmail: false,
      });
    } catch (err) {
      Logger.Error(
        "Error in /account/api/public/account/:accountId endpoint: ",
        err
      );
      return c.status(500);
    }
  });

  app.get("/api/v1/search/:accountId", verifyToken, async (c) => {
    const accountId = c.req.param("accountId");
    if (!accountId) return c.status(400);

    try {
      const users = await User.find({
        username: new RegExp(`^${c.req.query("prefix")}`),
        banned: false,
      }).lean<IUser[]>();

      if (users) {
        const response = users.map((user, index) => ({
          accountId: user.accountId,
          matches: [
            {
              value: user.username,
              platform: "epic",
            },
          ],
          matchType:
            c.req.query("prefix") == user.username ? "exact" : "prefix",
          epicMutuals: 0,
          sortPosition: index,
        }));

        return c.json(response);
      }
    } catch (err) {
      Logger.Error("Error in /api/v1/search/:accountId endpoint: ", err);
      return c.status(500);
    }
  });

  app.get("/epic/id/v2/sdk/accounts", verifyToken, async (c) => {
    const accountId = c.req.query("accountId");
    if (!accountId) return c.status(400);

    try {
      const user = await User.findOne({
        accountId,
        banned: false,
      }).lean<IUser>();
      if (!user)
        return error.createError(
          c,
          "errors.com.epicgames.account.account_not_found",
          `Sorry we couldn"t find an account for ${accountId}`,
          [accountId],
          18007,
          undefined,
          404
        );

      return c.json([
        {
          accountId: accountId,
          displayName: user.username,
          preferredLanguage: "en",
          cabinedMode: false,
          empty: false,
        },
      ]);
    } catch (err) {
      Logger.Error("Error in /epic/id/v2/sdk/accounts endpoint: ", err);
      return c.status(500);
    }
  });

  app.get("/statsproxy/api/statsv2/account/:accountId", (c) => {
    return c.json({
      startTime: 0,
      endTime: 0,
      stats: {},
      accountId: c.req.param("accountId"),
    });
  });

  app.get("/content-controls/:accountId", async (c) => {
    return c.json({
      data: {
        ageGate: 0,
        controlsEnabled: false,
        maxEpicProfilePrivacy: "none",
        principalId: c.req.param("accountId"),
      },
    });
  });

  app.get("/content-controls/:accountId/rules/namespaces/fn", async (c) => {
    return c.json([]);
  });

  app.post("/content-controls/:accountId/verify-pin", async (c) => {
    return c.json({
      data: {
        pinCorrect: true,
      },
    });
  });

  app.get("/fortnite/api/game/v2/br-inventory/account/:accountId", (c) =>
    c.json({
      stash: {
        globalcash: 67,
      },
    })
  );

  app.get("/fortnite/api/game/v2/privacy/account/:accountId", (c) =>
    c.json({
      accountId: c.req.param("accountId"),
      optOutOfPublicLeaderboards: false,
    })
  );

  app.get("/socialban/api/public/v1/:accountId", (c) => {
    return c.json({
      bans: [],
      warnings: [],
    });
  });

  app.get("/account/api/public/account/:accountId/externalAuths", (c) =>
    c.json([])
  );

  app.get("/fortnite/api/receipts/v1/account/:accountId/receipts", (c) =>
    c.json([])
  );

  app.get("/presence/api/v1/_/:accountId/last-online", (c) => c.json({}));

  app.get("/api/v2/interactions/aggregated/Fortnite/:accountId", async (c) => {
    return c.json([]);
  });
};
