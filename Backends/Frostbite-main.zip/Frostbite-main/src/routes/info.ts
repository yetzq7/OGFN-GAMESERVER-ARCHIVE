import { Hono } from "hono";
import fs from "fs";
import { GetVersionInfo, verifyToken } from "../utils/funcs";

export default (app: Hono) => {
  app.get("/content/api/pages/fortnite-game/", (c) => {
    const contentpages = JSON.parse(
      fs.readFileSync("./static/responses/contentpages.json", "utf-8")
    );

    const language = (() => {
      const acceptLanguageHeader = c.header("accept-language") as
        | string
        | undefined;
      if (!acceptLanguageHeader) return "en";

      if (acceptLanguageHeader === "es-419") return "es-419";
      if (acceptLanguageHeader.includes("-")) {
        return acceptLanguageHeader.split("-")[0]!.toLowerCase();
      }

      return acceptLanguageHeader.toLowerCase();
    })();

    const modes = [
      "saveTheWorldUnowned",
      "battleRoyale",
      "creative",
      "saveTheWorld",
    ];

    modes.forEach((mode) => {
      contentpages.subgameselectdata[mode].message.title =
        contentpages.subgameselectdata[mode].message.title[language];
      contentpages.subgameselectdata[mode].message.body =
        contentpages.subgameselectdata[mode].message.body[language];
    });

    const version = GetVersionInfo(c.req);
    contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage = `season${version.season}`;
    contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage = `season${version.season}`;

    if (version.season === 10) {
      contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage =
        "seasonx";
      contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage =
        "seasonx";
    }

    if (version.build === 11.31 || version.build === 11.4) {
      contentpages.dynamicbackgrounds.backgrounds.backgrounds[0].stage =
        "Winter19";
      contentpages.dynamicbackgrounds.backgrounds.backgrounds[1].stage =
        "Winter19";
    }

    return c.json(contentpages);
  });
};
