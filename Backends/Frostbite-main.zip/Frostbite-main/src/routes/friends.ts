import { Hono } from "hono";
import { verifyToken } from "../utils/funcs";
import { Logger } from "../utils/logger";
import Friends from "../database/models/friends";
import axios from "axios";
import * as error from "../utils/error";

export default (app: Hono) => {
  app.get("/friends/api/v1/:accountId/summary", verifyToken, async (c) => {
    const userAccountId = c.req.param("accountId");
    if (!userAccountId) return c.json({ error: "Unauthorized" }, 401);

    const response = {
      friends: [] as any[],
      incoming: [] as any[],
      outgoing: [] as any[],
      suggested: [] as any[],
      blocklist: [] as any[],
      settings: {
        acceptInvites: "public",
      },
    };

    const friends = await Friends.findOne({
      accountId: userAccountId,
    }).lean();

    friends!.list.accepted.forEach((acceptedFriend: any) => {
      response.friends.push({
        accountId: acceptedFriend.accountId,
        groups: [],
        mutual: 0,
        alias: acceptedFriend.alias ?? "",
        note: "",
        favorite: false,
        created: acceptedFriend.created,
      });
    });

    friends!.list.incoming.forEach((incomingFriend: any) => {
      response.incoming.push({
        accountId: incomingFriend.accountId,
        mutual: 0,
        favorite: false,
        created: incomingFriend.created,
      });
    });

    friends!.list.outgoing.forEach((outgoingFriend: any) => {
      response.outgoing.push({
        accountId: outgoingFriend.accountId,
        favorite: false,
      });
    });

    friends!.list.blocked.forEach((blockedFriend: any) => {
      response.blocklist.push({
        accountId: blockedFriend.accountId,
      });
    });

    return c.json(response);
  });

  app.all(
    "/friends/api/*/:accountId/friends/:friendId",
    verifyToken,
    async (c) => {
      const method = c.req.method;
      const accountId = c.req.param("accountId");
      const friendId = c.req.param("friendId");
      if (!accountId) return c.body(null, 400);

      const sender = await Friends.findOne({ accountId });
      const receiver = await Friends.findOne({ accountId: friendId });
      if (!sender || !receiver) return c.body(null, 403);

      const senderList = sender.list;
      const receiverList = receiver.list;
      const now = new Date().toISOString();

      async function sendMessage(targetId: string, body: object) {
        try {
          await axios.post(
            `http://localhost:80/api/voryn/message/send/${targetId}`,
            body
          );
        } catch (err: any) {
          Logger.Error(`Failed to send XMPP to ${targetId}:`, err.message);
        }
      }

      if (method === "DELETE") {
        let removed = false;

        for (const listType of [
          "accepted",
          "incoming",
          "outgoing",
          "blocked",
        ] as (keyof typeof senderList)[]) {
          const senderIndex = senderList[listType].findIndex(
            (i) => i.accountId === receiver.accountId
          );
          const receiverIndex = receiverList[listType].findIndex(
            (i) => i.accountId === sender.accountId
          );

          if (senderIndex !== -1) {
            senderList[listType].splice(senderIndex, 1);
            removed = true;
          }

          if (listType === "blocked") continue;

          if (receiverIndex !== -1) {
            receiverList[listType].splice(receiverIndex, 1);
          }
        }

        if (!removed) return c.body(null, 403);

        await sendMessage(sender.accountId, {
          payload: { accountId: receiver.accountId, reason: "DELETED" },
          type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
          timestamp: now,
        });

        await sendMessage(receiver.accountId, {
          payload: { accountId: sender.accountId, reason: "DELETED" },
          type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
          timestamp: now,
        });

        await sender.updateOne({ $set: { list: senderList } });
        await receiver.updateOne({ $set: { list: receiverList } });

        return c.body(null, 204);
      }

      if (method === "POST") {
        const isAlreadyFriends =
          senderList.accepted.some((i) => i.accountId === receiver.accountId) ||
          receiverList.accepted.some((i) => i.accountId === sender.accountId);

        const isBlocked =
          senderList.blocked.some((i) => i.accountId === receiver.accountId) ||
          receiverList.blocked.some((i) => i.accountId === sender.accountId);

        if (
          isAlreadyFriends ||
          isBlocked ||
          sender.accountId === receiver.accountId
        ) {
          return c.body(null, 403);
        }

        const isIncoming = senderList.incoming.find(
          (i: any) => i.accountId === receiver.accountId
        );
        const isOutgoing = senderList.outgoing.find(
          (i: any) => i.accountId === receiver.accountId
        );

        if (isIncoming) {
          senderList.incoming = senderList.incoming.filter(
            (i: any) => i.accountId !== receiver.accountId
          );
          senderList.accepted.push({
            accountId: receiver.accountId,
            created: now,
          });

          receiverList.outgoing = receiverList.outgoing.filter(
            (i: any) => i.accountId !== sender.accountId
          );
          receiverList.accepted.push({
            accountId: sender.accountId,
            created: now,
          });

          await sendMessage(sender.accountId, {
            payload: {
              accountId: receiver.accountId,
              status: "ACCEPTED",
              direction: "OUTBOUND",
              created: now,
              favorite: false,
            },
            type: "com.epicgames.friends.core.apiobjects.Friend",
            timestamp: now,
          });

          await sendMessage(receiver.accountId, {
            payload: {
              accountId: sender.accountId,
              status: "ACCEPTED",
              direction: "OUTBOUND",
              created: now,
              favorite: false,
            },
            type: "com.epicgames.friends.core.apiobjects.Friend",
            timestamp: now,
          });

          await sender.updateOne({ $set: { list: senderList } });
          await receiver.updateOne({ $set: { list: receiverList } });
        } else if (!isOutgoing) {
          senderList.outgoing.push({
            accountId: receiver.accountId,
            created: now,
          });
          receiverList.incoming.push({
            accountId: sender.accountId,
            created: now,
          });

          await sendMessage(sender.accountId, {
            payload: {
              accountId: receiver.accountId,
              status: "PENDING",
              direction: "OUTBOUND",
              created: now,
              favorite: false,
            },
            type: "com.epicgames.friends.core.apiobjects.Friend",
            timestamp: now,
          });

          await sendMessage(receiver.accountId, {
            payload: {
              accountId: sender.accountId,
              status: "PENDING",
              direction: "INBOUND",
              created: now,
              favorite: false,
            },
            type: "com.epicgames.friends.core.apiobjects.Friend",
            timestamp: now,
          });

          await sender.updateOne({ $set: { list: senderList } });
          await receiver.updateOne({ $set: { list: receiverList } });
        }

        return c.body(null, 204);
      }

      return c.json({ error: "Method Not Allowed" }, 405);
    }
  );

  app.all(
    "/friends/api/v1/:accountId/blocklist/:friendId",
    verifyToken,
    async (c) => {
      const method = c.req.method;
      const { friendId, accountId } = c.req.param();
      if (!accountId) return c.body(null, 401);

      const sender = await Friends.findOne({ accountId }).lean();
      const receiver = await Friends.findOne({ accountId: friendId }).lean();
      if (!sender || !receiver) return c.body(null, 403);

      const senderFull = await Friends.findOne({ accountId });
      if (!senderFull) return c.body(null, 403);

      if (method === "POST") {
        if (
          sender.list.blocked.find((i) => i.accountId === receiver.accountId) ||
          sender.accountId === receiver.accountId
        )
          return c.body(null, 403);

        const fromFriends = senderFull.list;
        const to = await Friends.findOne({ accountId: receiver.accountId });
        if (!to) return c.body(null, 403);
        const toFriends = to.list;

        let removed = false;
        for (const listType of [
          "accepted",
          "incoming",
          "outgoing",
          "blocked",
        ] as (keyof typeof fromFriends)[]) {
          const findFriend = fromFriends[listType].findIndex(
            (i) => i.accountId === to.accountId
          );
          const findToFriend = toFriends[listType].findIndex(
            (i) => i.accountId === sender.accountId
          );

          if (findFriend !== -1) {
            fromFriends[listType].splice(findFriend, 1);
            removed = true;
          }

          if (listType === "blocked") continue;
          if (findToFriend !== -1) toFriends[listType].splice(findToFriend, 1);
        }

        if (removed) {
          const now = new Date().toISOString();

          await axios.post(
            `http://localhost:80/api/voryn/message/send/${sender.accountId}`,
            {
              payload: { accountId: to.accountId, reason: "DELETED" },
              type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
              timestamp: now,
            }
          );

          await axios.post(
            `http://localhost:80/api/voryn/message/send/${to.accountId}`,
            {
              payload: { accountId: sender.accountId, reason: "DELETED" },
              type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
              timestamp: now,
            }
          );

          await senderFull.updateOne({ $set: { list: fromFriends } });
          await to.updateOne({ $set: { list: toFriends } });
        }

        fromFriends.blocked.push({
          accountId: to.accountId,
          created: new Date().toISOString(),
        });
        await senderFull.updateOne({ $set: { list: fromFriends } });

        await axios.post(
          `http://localhost:80/api/voryn/presence/send/${senderFull.accountId}/${receiver.accountId}?offline=true`
        );
        await axios.post(
          `http://localhost:80/api/voryn/presence/send/${receiver.accountId}/${senderFull.accountId}?offline=true`
        );

        return c.body(null, 204);
      }

      if (method === "DELETE") {
        const from = await Friends.findOne({ accountId });
        const to = await Friends.findOne({ accountId: friendId });
        if (!from || !to) return c.body(null, 403);

        const fromFriends = from.list;
        const toFriends = to.list;

        let removed = false;

        for (const listType of [
          "accepted",
          "incoming",
          "outgoing",
          "blocked",
        ] as (keyof typeof fromFriends)[]) {
          const senderIndex = fromFriends[listType].findIndex(
            (i) => i.accountId === to.accountId
          );
          const receiverIndex = toFriends[listType].findIndex(
            (i) => i.accountId === from.accountId
          );

          if (senderIndex !== -1) {
            fromFriends[listType].splice(senderIndex, 1);
            removed = true;
          }

          if (listType === "blocked") continue;
          if (receiverIndex !== -1)
            toFriends[listType].splice(receiverIndex, 1);
        }

        if (!removed) return c.body(null, 403);

        const now = new Date().toISOString();

        await axios.post(
          `http://localhost:80/api/voryn/message/send/${from.accountId}`,
          {
            payload: { accountId: to.accountId, reason: "DELETED" },
            type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
            timestamp: now,
          }
        );

        await axios.post(
          `http://localhost:80/api/voryn/message/send/${to.accountId}`,
          {
            payload: { accountId: from.accountId, reason: "DELETED" },
            type: "com.epicgames.friends.core.apiobjects.FriendRemoval",
            timestamp: now,
          }
        );

        await from.updateOne({ $set: { list: fromFriends } });
        await to.updateOne({ $set: { list: toFriends } });

        await axios.post(
          `http://localhost:80/api/voryn/presence/send/${from.accountId}/${to.accountId}?offline=true`
        );
        await axios.post(
          `http://localhost:80/api/voryn/presence/send/${to.accountId}/${from.accountId}?offline=true`
        );

        return c.body(null, 204);
      }

      return c.json({ error: "Method Not Allowed" }, 405);
    }
  );

  app.all(
    "/friends/api/v1/:accountId/friends/:friendId/alias",
    verifyToken,
    async (c) => {
      const { accountId, friendId } = c.req.param();
      const method = c.req.method;
      const rawBody = await c.req.text();

      const allowedCharacters = new Set(
        " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
      );

      for (const ch of rawBody) {
        if (!allowedCharacters.has(ch)) {
          return error.createError(
            c,
            "errors.com.epicgames.alias.invalid_field",
            "Invalid fields in [alias]",
            ["[alias]"],
            1040,
            undefined,
            404
          );
        }
      }

      const friends = await Friends.findOne({ accountId });
      if (!friends) {
        return error.createError(
          c,
          "errors.com.epicgames.friends.friendship_not_found",
          `Friendship between ${accountId} and ${friendId} does not exist`,
          [accountId, friendId],
          14004,
          undefined,
          404
        );
      }

      const friendIndex = friends.list.accepted.findIndex(
        (f: any) => f.accountId === friendId
      );
      if (friendIndex === -1) {
        return error.createError(
          c,
          "errors.com.epicgames.friends.friendship_not_found",
          `Friendship between ${accountId} and ${friendId} does not exist`,
          [accountId, friendId],
          14004,
          undefined,
          404
        );
      }

      switch (method) {
        case "PUT": {
          const aliasBytes = Buffer.byteLength(rawBody, "utf8");
          if (aliasBytes < 3 || aliasBytes > 16) {
            return error.createError(
              c,
              "errors.com.epicgames.alias.invalid_size",
              "Alias must be 3–16 bytes",
              ["[alias]"],
              1040,
              undefined,
              404
            );
          }

          friends.list.accepted[friendIndex]!.alias = rawBody;
          await friends.updateOne({ $set: { list: friends.list } });
          break;
        }

        case "DELETE": {
          friends.list.accepted[friendIndex]!.alias = "";
          await friends.updateOne({ $set: { list: friends.list } });
          break;
        }
      }

      return c.body(null, 204);
    }
  );

  app.get("/friends/api/v1/:accountId/recent/fortnite", (c) => c.json([]));
};
