import { Hono } from "hono";
import { getConnInfo } from "hono/bun";
import User, { type IUser } from "../database/models/user";
import Profiles from "../database/models/profiles";
import Friends from "../database/models/friends";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import * as error from "../utils/error";
import * as functions from "../utils/funcs";
import { Logger } from "../utils/logger";
import { DeviceAuth } from "../database/models/deviceauth";
import { TokenStore } from "../database/models/tokens";

const g = global as unknown as NodeJS.Global;

export default (app: Hono) => {
  app.post("/account/api/oauth/token", async (c) => {
    const authHeader = c.req.header("authorization");
    if (!authHeader) return c.status(400);

    let clientId: string;
    try {
      const encoded = authHeader.split(" ")[1] || "";
      clientId = Buffer.from(encoded, "base64")
        .toString("utf-8")
        .split(":")[0]!;
    } catch {
      return error.createError(
        c,
        "errors.com.epicgames.common.oauth.invalid_client",
        "Authorization header is malformed.",
        [],
        1011,
        "invalid_client",
        400
      );
    }

    const contentType = c.req.header("content-type") || "";
    let payload: Record<string, string>;

    if (contentType.includes("application/json")) {
      payload = await c.req.json();
    } else if (contentType.includes("application/x-www-form-urlencoded")) {
      const form = await c.req.formData();
      payload = Object.fromEntries(form as any);
    } else {
      return c.text("Unsupported Content-Type", 415);
    }

    const grant = payload.grant_type;
    let user;

    const version = functions.GetVersionInfo(c.req);
    if (
      version.build !== Number(process.env.VERSION) &&
      grant !== "client_credentials"
    ) {
      return error.createError(
        c,
        "errors.com.epicgames.common.version_not_active",
        "You are using an unsupported version.",
        [],
        -1,
        undefined,
        400
      );
    }

    switch (grant) {
      case "client_credentials":
        const conn = getConnInfo(c);
        let ip = conn.remote.address!;
        if (ip.startsWith("::ffff:")) ip = ip.replace("::ffff:", "");

        const token = functions.createClient(clientId, grant, 4);
        const decoded = jwt.decode(token) as any;

        const expire = new Date(
          new Date(decoded.creation_date).getTime() +
            decoded.hours_expire * 60 * 60 * 1000
        );

        return c.json({
          access_token: token,
          expires_in: Math.round((expire.getTime() - Date.now()) / 1000),
          expires_at: expire.toISOString(),
          token_type: "bearer",
          client_id: clientId,
          internal_client: true,
          client_service: "fortnite",
        });
      case "password":
        const { username, password } = payload;

        user = await User.findOne({ email: username }).lean<IUser>();
        if (!user)
          return error.createError(
            c,
            "errors.com.epicgames.account.invalid_account_credentials",
            "Your e-mail and/or password are incorrect. Please check them and try again.",
            [],
            18031,
            "invalid_grant",
            400
          );
        if (!(await bcrypt.compare(password!, user.password)))
          return error.createError(
            c,
            "errors.com.epicgames.account.invalid_account_credentials",
            "Your e-mail and/or password are incorrect. Please check them and try again.",
            [],
            18031,
            "invalid_grant",
            400
          );
        break;
      case "authorization_code":
        const authCode = payload.code || "";

        let findAuthCode = g.authorizationCodes?.find(
          (ac) => ac.code === authCode
        );

        user = await User.findOne({
          accountId: findAuthCode?.accountId,
        }).lean<IUser>();
        if (user)
          g.authorizationCodes = g.authorizationCodes.filter(
            (ac) => ac.code !== authCode
          );
        break;
      case "exchange_code":
        const exchangeCode = payload.code || "";

        let findExchangeCode = g.exchangeCodes?.find(
          (ec) => ec.code === exchangeCode
        );

        user = await User.findOne({
          accountId: findExchangeCode?.accountId,
        }).lean<IUser>();
        if (user)
          g.exchangeCodes = g.exchangeCodes.filter(
            (ec) => ec.code !== exchangeCode
          );
        break;
      case "device_auth": {
        const { account_id, device_id, secret } = payload;

        const auth = await DeviceAuth.findOne({
          accountId: account_id,
          deviceId: device_id,
          secret,
        }).lean();

        if (auth) {
          user = await User.findOne({
            accountId: auth.accountId,
          }).lean<IUser>();
        }
        break;
      }
      default:
        error.createError(
          c,
          "errors.com.epicgames.common.oauth.unsupported_grant_type",
          `Unsupported grant type: ${grant}`,
          [],
          1016,
          "unsupported_grant_type",
          400
        );
        return;
    }

    if (!user) {
      return error.createError(
        c,
        "errors.com.epicgames.account.account_not_found",
        "Your account is not found possibly because of invalid credentials.",
        [],
        -1,
        undefined,
        404
      );
    }

    if (user.banned) {
      return error.createError(
        c,
        "errors.com.epicgames.account.account_not_active",
        "You have been permanently banned from Fortnite.",
        [],
        -1,
        undefined,
        400
      );
    }

    const deviceId = payload.device_id || functions.MakeID();
    const access = functions.createAccess(user, clientId, grant!, deviceId, 8);
    const refresh = functions.createRefresh(
      user,
      clientId,
      grant!,
      deviceId,
      24
    );

    await TokenStore.findOneAndUpdate(
      { accountId: user.accountId },
      { accessToken: access, refreshToken: refresh },
      { upsert: true, new: true }
    );

    const a = jwt.decode(access) as any;
    const r = jwt.decode(refresh) as any;
    const accessExpire = new Date(
      new Date(a.creation_date).getTime() + a.hours_expire * 60 * 60 * 1000
    );
    const refreshExpire = new Date(
      new Date(r.creation_date).getTime() + r.hours_expire * 60 * 60 * 1000
    );

    dailyVbucks(user);

    return c.json({
      access_token: access,
      expires_in: Math.round((accessExpire.getTime() - Date.now()) / 1000),
      expires_at: accessExpire.toISOString(),
      token_type: "bearer",
      refresh_token: refresh,
      refresh_expires: Math.round(
        (refreshExpire.getTime() - Date.now()) / 1000
      ),
      refresh_expires_at: refreshExpire.toISOString(),
      account_id: user.accountId,
      client_id: clientId,
      internal_client: true,
      client_service: "fortnite",
      displayName: user.username,
      app: "fortnite",
      in_app_id: user.accountId,
      device_id: deviceId,
    });
  });

  app.get("/account/api/oauth/verify", async (c) => {
    const auth = c.req.header("authorization") || "";
    const raw = auth.replace(/bearer\s+/i, "");
    const decoded = jwt.decode(raw) as any;

    if (!decoded || !decoded.sub) {
      return error.createError(
        c,
        "errors.com.epicgames.common.oauth.invalid_token",
        "Invalid or missing token.",
        [],
        1013,
        "invalid_token",
        401
      );
    }

    const user = await User.findOne({ accountId: decoded.sub });
    if (!user) {
      return error.createError(
        c,
        "errors.com.epicgames.account.not_found",
        "User not found.",
        [],
        18007,
        undefined,
        404
      );
    }

    const expiry = new Date(
      new Date(decoded.creation_date).getTime() +
        decoded.hours_expire * 60 * 60 * 1000
    );
    const remaining = Math.max(
      0,
      Math.round((expiry.getTime() - Date.now()) / 1000)
    );

    return c.json({
      token: raw,
      session_id: decoded.jti,
      token_type: "bearer",
      client_id: decoded.clid,
      internal_client: true,
      client_service: "fortnite",
      account_id: user.accountId,
      expires_in: remaining,
      expires_at: expiry.toISOString(),
      auth_method: decoded.am,
      display_name: user.username,
      app: "fortnite",
      in_app_id: user.accountId,
      device_id: decoded.dvid,
    });
  });

  app.delete("/account/api/oauth/sessions/kill", (c) => c.body(null, 204));

  app.delete("/account/api/oauth/sessions/kill/:token", async (c) => {
    const token = c.req.param("token");

    const doc = await TokenStore.findOne({
      $or: [{ accessToken: token }, { refreshToken: token }],
    }).exec();

    await TokenStore.deleteOne({ _id: doc!._id }).exec();

    return c.body(null, 204);
  });

  app.post("/auth/v1/oauth/token", (c) => {
    return c.json({
      access_token: "frosttoken",
      token_type: "bearer",
      expires_at: "9999-12-31T23:59:59.999Z",
      features: ["AntiCheat", "Connect", "Ecom"],
      organization_id: "frostorgid",
      product_id: "prod-fn",
      sandbox_id: "fn",
      deployement_id: "frostdeployid",
      expires_in: 3599,
    });
  });

  app.post(
    "/account/api/public/account/:accountId/deviceAuth",
    functions.verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");

      const conn = getConnInfo(c);
      let ip = conn.remote.address || "";
      if (ip.startsWith("::ffff:")) ip = ip.replace("::ffff:", "");

      const hashedIp = crypto.createHash("sha256").update(ip).digest("hex");

      const deviceId = functions.MakeID();
      const secret = functions.MakeID();
      const userAgent = c.req.header("user-agent") ?? "";

      const deviceAuth = new DeviceAuth({
        deviceId,
        accountId,
        secret,
        userAgent,
        created: {
          location: "EU",
          ipAddress: hashedIp,
          dateTime: new Date(),
        },
      });

      try {
        await deviceAuth.save();
        return c.json(deviceAuth.toObject());
      } catch (err: any) {
        if (err.code === 11000) {
          return error.createError(
            c,
            "errors.com.epicgames.account.device_auth_conflict",
            "Device auth already exists for this accountId/deviceId pair.",
            [accountId, deviceId],
            18057,
            undefined,
            409
          );
        }
        throw err;
      }
    }
  );

  app.delete(
    "/account/api/public/account/:accountId/deviceAuth/:deviceId",
    async (c) => {
      const accountId = c.req.param("accountId");
      const deviceId = c.req.param("deviceId");

      await DeviceAuth.findOneAndDelete({
        accountId,
        deviceId,
      });

      return c.body(null, 204);
    }
  );

  interface LoginToken {
    token: string;
    accountId: string;
  }

  const loginTokens: LoginToken[] = [];

  app.post("/account/api/oauth/login", async (c) => {
    const form = await c.req.formData();
    const payload = Object.fromEntries(form as any);

    const { email, password } = payload;

    const user = await User.findOne({ email }).lean<IUser>();
    if (!user)
      return error.createError(
        c,
        "errors.com.epicgames.common.account_not_found",
        "Account not found.",
        [],
        404,
        undefined,
        404
      );

    const valid = await bcrypt.compare(password, user.password);
    if (!valid)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_password",
        "Incorrect email or password.",
        [],
        403,
        undefined,
        403
      );

    const token = functions.MakeID();
    loginTokens.push({ token, accountId: user.accountId });
    setTimeout(
      () => {
        const index = loginTokens.findIndex((t) => t.token === token);
        if (index !== -1) loginTokens.splice(index, 1);
      },
      10 * 60 * 1000
    );

    return c.json({
      username: user.username,
      accountId: user.accountId,
      token: token,
      token_type: "bearer",
      expires_in: 3600,
    });
  });

  app.post("/account/api/oauth/register", async (c) => {
    const form = await c.req.formData();
    const payload = Object.fromEntries(form as any);

    const { username, email, password } = payload;

    if (!username || !email || !password)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_request",
        "Missing credentials.",
        [],
        400,
        undefined,
        400
      );

    if (await User.findOne({ email }).lean<IUser>())
      return error.createError(
        c,
        "errors.com.epicgames.common.used_email",
        "Email already in use.",
        [],
        409,
        undefined,
        409
      );

    if (await User.findOne({ username }).lean<IUser>())
      return error.createError(
        c,
        "errors.com.epicgames.common.used_username",
        "Username already in use.",
        [],
        409,
        undefined,
        409
      );

    const emailFilter =
      /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!emailFilter.test(email))
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_email",
        "Invalid email format.",
        [],
        400,
        undefined,
        400
      );
    if (username.length >= 25)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_username",
        "Your username must be less than 25 characters.",
        [],
        400,
        undefined,
        400
      );
    if (username.length < 3)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_username",
        "Your username must be atleast 3 characters long.",
        [],
        400,
        undefined,
        400
      );
    if (password.length >= 128)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_password",
        "Your password must be less than 128 characters.",
        [],
        400,
        undefined,
        400
      );
    if (password.length < 4)
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_password",
        "Your password must be atleast 4 characters long.",
        [],
        400,
        undefined,
        400
      );
    const allowedCharacters =
      " !\"#$%&'()*+,-./0123456789:<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~".split(
        ""
      );

    const allowedRegex = new RegExp(
      `^[${allowedCharacters.map((c) => `\\${c}`).join("")}]+$`
    );

    if (!allowedRegex.test(username)) {
      return error.createError(
        c,
        "errors.com.epicgames.common.invalid_username",
        "Your username contains invalid characters.",
        [],
        400,
        undefined,
        400
      );
    }

    const accountId = functions.MakeID();
    const matchmakingId = functions.MakeID();
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
      const userDoc = await User.create({
        created: new Date().toISOString(),
        accountId,
        username,
        email,
        password: hashedPassword,
        matchmakingId,
        isServer: false,
        acceptedEULA: false,
        lastVbucksClaim: 0,
        arena: {
          division: 1,
          hype: 0,
        },
      });

      const profiles = functions.createProfiles(accountId);
      await Profiles.create({
        accountId: userDoc.accountId,
        profiles: profiles,
      });

      await Friends.create({
        accountId: userDoc.accountId,
      });

      return c.json({ message: "Account successfully created!" }, 201);
    } catch (err) {
      Logger.Error(
        "Failed to create an account at /account/api/oauth/register: ",
        err
      );
      return c.status(500);
    }
  });

  app.get("/id/api/redirect", async (c) => {
    const clientId = c.req.query("clientId");

    const authHeader = c.req.header("authorization")?.replace(/bearer\s+/i, "");
    if (!authHeader) return c.text("Missing authorization header", 401);

    const tokenObj = loginTokens.find((t) => t.token === authHeader);
    if (!tokenObj) return c.text("Invalid or expired token", 401);

    let authCodeObj = g.authorizationCodes?.find(
      (ac: { accountId: string; code: string }) =>
        ac.accountId === tokenObj.accountId
    );

    if (!authCodeObj) {
      const newCode = functions.MakeID();
      authCodeObj = { accountId: tokenObj.accountId, code: newCode };
      g.authorizationCodes = g.authorizationCodes || [];
      g.authorizationCodes.push(authCodeObj);

      setTimeout(
        () => {
          g.authorizationCodes = g.authorizationCodes?.filter(
            (ac) => ac.code !== newCode
          );
        },
        5 * 60 * 1000
      );
    }

    const redirectUrl =
      clientId === "3f69e56c7649492c8cc29f1af08a8a12"
        ? `com.epicgames.fortnite://fnauth/?code=${authCodeObj.code}`
        : `http://localhost/?code=${authCodeObj.code}`;

    return c.json({
      redirectUrl,
      authorizationCode: authCodeObj.code,
      exchangeCode: null,
      sid: null,
    });
  });
};

const dailyVbucks = async (user: IUser) => {
  try {
    const profile = await Profiles.findOne({ accountId: user.accountId });
    if (!profile) {
      throw new Error(`Profile not found for user ${user.username}`);
    }

    const now = new Date();
    const lastClaim = user.lastVbucksClaim
      ? new Date(user.lastVbucksClaim)
      : new Date(0);
    const hoursSinceLastClaim =
      (now.getTime() - lastClaim.getTime()) / 1000 / 3600;

    if (hoursSinceLastClaim < 24) {
      return false;
    }

    const commonCore = (profile.profiles as any).common_core;

    if (!commonCore.items["Currency:MtxPurchased"]) {
      commonCore.items["Currency:MtxPurchased"] = { quantity: 0 };
    }

    commonCore.items["Currency:MtxPurchased"].quantity += 100; // Vbucks value

    const purchaseId = functions.MakeID();
    const lootList = [
      {
        itemType: "Currency:MtxPurchased",
        itemGuid: "Currency:MtxPurchased",
        quantity: 100,
      },
    ];

    commonCore.items[purchaseId] = {
      templateId: "GiftBox:GB_MakeGood",
      attributes: {
        fromAccountId: "[Administrator]",
        lootList: lootList,
        params: {
          userMessage: "Your daily V-Bucks, Thanks for playing Frostbite.",
        },
        giftedOn: new Date().toISOString(),
      },
      quantity: 1,
    };

    commonCore.rvn++;
    commonCore.commandRevision++;

    await Promise.all([
      Profiles.updateOne(
        { accountId: user.accountId },
        { $set: { "profiles.common_core": commonCore } }
      ),
      User.updateOne(
        { accountId: user.accountId },
        { $set: { lastVbucksClaim: now } }
      ),
    ]);

    return {
      success: true,
      profileRevision: commonCore.rvn,
      profileCommandRevision: commonCore.commandRevision,
      newQuantity: commonCore.items["Currency:MtxPurchased"].quantity,
    };
  } catch (err) {
    throw new Error(err instanceof Error ? err.message : String(err));
  }
};
