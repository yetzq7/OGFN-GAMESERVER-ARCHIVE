import { Hono } from "hono";
import fs from "fs";

export default (app: Hono) => {
  app.get("/region", (c) =>
    c.json({
      continent: {
        code: "EU",
        geoname_id: 6255148,
        names: {
          de: "Europa",
          en: "Europe",
          es: "Europa",
          it: "Europa",
          fr: "Europe",
          ja: "ヨーロッパ",
          "pt-BR": "Europa",
          ru: "Европа",
          "zh-CN": "欧洲",
        },
      },
      country: {
        geoname_id: 2635167,
        is_in_european_union: false,
        iso_code: "GB",
        names: {
          de: "UK",
          en: "United Kingdom",
          es: "RU",
          it: "Stati Uniti",
          fr: "Royaume Uni",
          ja: "英国",
          "pt-BR": "Reino Unido",
          ru: "Британия",
          "zh-CN": "英国",
        },
      },
      subdivisions: [
        {
          geoname_id: 6269131,
          iso_code: "ENG",
          names: {
            de: "England",
            en: "England",
            es: "Inglaterra",
            it: "Inghilterra",
            fr: "Angleterre",
            ja: "イングランド",
            "pt-BR": "Inglaterra",
            ru: "Англия",
            "zh-CN": "英格兰",
          },
        },
        {
          geoname_id: 3333157,
          iso_code: "KEC",
          names: {
            en: "Royal Kensington and Chelsea",
          },
        },
      ],
    })
  );

  app.get("/account/api/epicdomains/ssodomains", (c) =>
    c.json([
      "unrealengine.com",
      "unrealtournament.com",
      "fortnite.com",
      "epicgames.com",
    ])
  );

  app.get("/v1/epic-settings/public/users/:accountId/values", (c) => {
    const epicSettings = JSON.parse(
      fs.readFileSync("./static/responses/epic-settings.json", "utf-8")
    );
    return c.json(epicSettings);
  });

  app.get("/sdk/v1/*", (c) => {
    const sdk = JSON.parse(
      fs.readFileSync("./static/responses/sdk.json", "utf-8")
    );
    return c.json(sdk);
  });

  app.post("/datarouter/api/v1/public/data", (c) => c.body(null, 204));

  app.get("/fortnite/api/game/v2/enabled_features", (c) => c.json([]));

  app.post("/fortnite/api/game/v2/chat/*/*/*/*", (c) => c.json({}));

  app.post("/fortnite/api/game/v2/tryPlayOnPlatform/account/*", (c) => {
    c.header("Content-Type", "text/plain");
    return c.text("true");
  });

  app.get("/waitingroom/api/waitingroom", (c) => c.body(null, 204));

  app.post("/*/api/statsv2/query", (c) => c.json([]));

  app.get("/fortnite/api/game/v2/world/info", (c) => c.json({}));

  app.post("/api/v1/user/setting", (c) => c.json({}));
};
