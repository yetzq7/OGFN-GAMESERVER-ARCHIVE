import { Hono } from "hono";
import fs from "fs";
import path from "path";
import User, { type IUser } from "../database/models/user.ts";
import { GetVersionInfo } from "../utils/funcs.ts";
import { Logger } from "../utils/logger.ts";

export default (app: Hono) => {
  app.get("/api/v1/events/Fortnite/download/:accountId", async (c) => {
    const accountId = c.req.param("accountId") || c.req.query("accountId");

    try {
      const user = await User.findOne({
        accountId,
        banned: false,
      }).lean<IUser>();

      const eventsPath = path.join(
        __dirname,
        "../../static/Events/events.json"
      );
      const templatesPath = path.join(
        __dirname,
        "../../static/Events/template.json"
      );

      const eventsData = JSON.parse(fs.readFileSync(eventsPath, "utf-8"));
      const templatesData = JSON.parse(fs.readFileSync(templatesPath, "utf-8"));

      const version = GetVersionInfo(c.req);
      const seasonStr = `S${version.season}`;

      const updatedEvents = eventsData.map((evt: any) => {
        const eventObj = JSON.parse(JSON.stringify(evt));

        if (typeof eventObj.eventId === "string") {
          eventObj.eventId = eventObj.eventId.replace(/S16/g, seasonStr);
        }

        if (Array.isArray(eventObj.eventWindows)) {
          eventObj.eventWindows = eventObj.eventWindows.map((window: any) => {
            const w = { ...window };
            if (typeof w.eventTemplateId === "string")
              w.eventTemplateId = w.eventTemplateId.replace(/S16/g, seasonStr);
            if (typeof w.eventWindowId === "string")
              w.eventWindowId = w.eventWindowId.replace(/S16/g, seasonStr);
            if (Array.isArray(w.requireAllTokens))
              w.requireAllTokens = w.requireAllTokens.map((t: string) =>
                t.replace(/S16/g, seasonStr)
              );
            if (Array.isArray(w.requireNoneTokensCaller))
              w.requireNoneTokensCaller = w.requireNoneTokensCaller.map(
                (t: string) => t.replace(/S16/g, seasonStr)
              );
            return w;
          });
        }

        return eventObj;
      });

      const updatedTemplates = templatesData.map((template: any) => {
        const t = { ...template };
        if (typeof t.eventTemplateId === "string")
          t.eventTemplateId = t.eventTemplateId.replace(/S16/g, seasonStr);
        return t;
      });

      const arena = {
        events: updatedEvents,
        player: {
          accountId: accountId!,
          gameId: "Fortnite",
          groupIdentity: {},
          pendingPayouts: [],
          pendingPenalties: {},
          persistentScores: {
            Hype: user?.arena.hype || 0,
          },
          teams: {
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division1_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division2_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division3_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division4_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division5_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division6_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division7_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division8_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division9_Solo`]:
              [accountId],
            [`epicgames_Arena_${seasonStr}_Solo:Arena_${seasonStr}_Division10_Solo`]:
              [accountId],
          },
          tokens: [`ARENA_${seasonStr}_Division${user?.arena.division || 1}`],
        },
        templates: updatedTemplates,
      };

      return c.json(arena);
    } catch (err) {
      Logger.Error(err);
      return c.status(500);
    }
  });
};
