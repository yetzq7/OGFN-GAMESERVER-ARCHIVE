import { Hono } from "hono";
import { GetVersionInfo, verifyToken, MakeID } from "../utils/funcs";
import {
  handleTierPurchase,
  handleBattlePassPurchase,
  handleCatalogPurchase,
} from "../utils/purchaseHandler";
import fs from "fs";
import path from "path";
import Profiles from "../database/models/profiles";
import * as error from "../utils/error";
import * as shop from "../utils/shop";

export default (app: Hono) => {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/:operation",
    verifyToken,
    async (c) => {
      const accountId = c.req.param("accountId");
      const operationName = c.req.param("operation");
      const query = c.req.query();
      const profileId = query.profileId as string;

      const supportedOps = new Set([
        "QueryProfile",
        "ClientQuestLogin",
        "RefreshExpeditions",
        "GetMcpTimeForLogin",
        "IncrementNamedCounterStat",
        "SetHardcoreModifier",
        "SetMtxPlatform",
        "BulkEquipBattleRoyaleCustomization",
        "RemoveGiftBox",
        "SetCosmeticLockerSlot",
        "SetCosmeticLockerBanner",
        "MarkItemSeen",
        "SetItemFavoriteStatusBatch",
        "CopyCosmeticLoadout",
        "SetCosmeticLockerName",
        "DeleteCosmeticLoadout",
        "SetRandomCosmeticLoadoutFlag",
        "PurchaseCatalogEntry",
        "RefundMtxPurchase",
      ]);

      if (!supportedOps.has(operationName)) {
        return error.createError(
          c,
          "errors.com.epicgames.fortnite.operation_not_found",
          `Operation '${operationName}' is not recognized`,
          [operationName],
          16035,
          undefined,
          404
        );
      }

      const userProfileDoc = await Profiles.findOne({ accountId });
      if (!userProfileDoc) {
        return error.createError(
          c,
          "errors.com.epicgames.modules.profiles.not_found",
          `No profiles found for account ${accountId}`,
          [accountId],
          404,
          undefined,
          404
        );
      }

      const profile = (userProfileDoc.profiles as any)[profileId];
      if (!profile) {
        return error.createError(
          c,
          "errors.com.epicgames.modules.profiles.not_found",
          `Profile ${profileId} not found for account ${accountId}`,
          [profileId],
          404,
          undefined,
          404
        );
      }

      const versionInfo = GetVersionInfo(c.req);
      if (profileId === "athena") {
        profile.stats.attributes.season_num = versionInfo.season;
      }

      const baseRevision = profile.rvn;
      const serverRvn =
        versionInfo.build >= 12.2 ? profile.commandRevision : profile.rvn;

      const changes: any[] = [];

      switch (operationName) {
        case "RemoveGiftBox":
          {
            const { giftBoxItemId, giftBoxItemIds } = (await c.req.json()) as {
              giftBoxItemId?: string;
              giftBoxItemIds?: string[];
            };

            function removeGiftBox(id: string) {
              if (!profile.items[id]) return false;
              if (!profile.items[id].templateId.startsWith("GiftBox:"))
                return false;
              delete profile.items[id];
              changes.push({ changeType: "itemRemoved", itemId: id });
              return true;
            }

            if (giftBoxItemId) removeGiftBox(giftBoxItemId);
            if (Array.isArray(giftBoxItemIds)) {
              for (const id of giftBoxItemIds) {
                if (typeof id === "string") removeGiftBox(id);
              }
            }
          }

          profile.rvn++;
          profile.commandRevision++;
          profile.updated = new Date().toISOString();

          await userProfileDoc.updateOne({
            $set: { [`profiles.${profileId}`]: profile },
          });
          break;

        case "SetCosmeticLockerSlot":
          {
            const body = await c.req.json<{
              category: string;
              lockerItem: string;
              itemToSlot?: string;
              slotIndex?: number;
              variantUpdates?: { channel: string; active: string }[];
            }>();

            const requiredFields = ["category", "lockerItem"];
            const missingFields = requiredFields.filter(
              (f) => !body[f as keyof typeof body]
            );
            if (missingFields.length) return c.status(400);

            if (!profile.items) profile.items = {};

            let itemToSlotID = "";
            if (body.itemToSlot) {
              for (const itemId in profile.items) {
                if (
                  profile.items[itemId].templateId.toLowerCase() ===
                  body.itemToSlot.toLowerCase()
                ) {
                  itemToSlotID = itemId;
                  break;
                }
              }
            }

            const lockerItemObj = profile.items[body.lockerItem];
            if (
              lockerItemObj.templateId.toLowerCase() !==
              "cosmeticlocker:cosmeticlocker_athena"
            ) {
              return error.createError(
                c,
                "errors.com.epicgames.fortnite.id_invalid",
                "lockerItem id is not a cosmeticlocker",
                ["lockerItem"],
                16027,
                undefined,
                400
              );
            }

            if (profile.items[itemToSlotID]) {
              const targetItem = profile.items[itemToSlotID];
              if (
                Array.isArray(body.variantUpdates) &&
                typeof body.slotIndex === "number"
              ) {
                const lockerSlots =
                  lockerItemObj.attributes.locker_slots_data.slots[
                    body.category
                  ];
                if (!lockerSlots.activeVariants)
                  lockerSlots.activeVariants = [];
                while (lockerSlots.activeVariants.length <= body.slotIndex) {
                  lockerSlots.activeVariants.push({ variants: [] });
                }

                lockerSlots.activeVariants[body.slotIndex] = {
                  variants: body.variantUpdates
                    .filter(
                      (variant) => variant && variant.channel && variant.active
                    )
                    .map((variant) => ({
                      channel: variant.channel,
                      active: variant.active,
                    })),
                };

                for (const variant of body.variantUpdates) {
                  if (!variant || !variant.channel || !variant.active) continue;
                  const idx = targetItem.attributes.variants.findIndex(
                    (v: { channel: string }) => v.channel === variant.channel
                  );
                  if (idx === -1) continue;
                  if (
                    !targetItem.attributes.variants[idx].owned.includes(
                      variant.active
                    )
                  )
                    continue;

                  targetItem.attributes.variants[idx].active = variant.active;
                }
              }
            }

            switch (body.category) {
              case "Dance": {
                const danceSlots =
                  lockerItemObj.attributes.locker_slots_data.slots.Dance;
                if (
                  danceSlots &&
                  typeof body.slotIndex === "number" &&
                  body.slotIndex >= 0 &&
                  body.slotIndex <= 5
                ) {
                  danceSlots.items[body.slotIndex] = body.itemToSlot;
                  profile.stats.attributes.favorite_dance[body.slotIndex] =
                    itemToSlotID || body.itemToSlot;
                  changes.push({
                    changeType: "itemAttrChanged",
                    itemId: body.lockerItem,
                    attributeName: "locker_slots_data",
                    attributeValue: lockerItemObj.attributes.locker_slots_data,
                  });
                }
                break;
              }

              case "ItemWrap": {
                const wrapSlots =
                  lockerItemObj.attributes.locker_slots_data.slots.ItemWrap;
                if (wrapSlots && typeof body.slotIndex === "number") {
                  if (body.slotIndex >= 0 && body.slotIndex <= 7) {
                    wrapSlots.items[body.slotIndex] = body.itemToSlot;
                    profile.stats.attributes.favorite_itemwraps[
                      body.slotIndex
                    ] = itemToSlotID || body.itemToSlot;
                  } else if (body.slotIndex === -1) {
                    for (let i = 0; i < 7; i++) {
                      wrapSlots.items[i] = body.itemToSlot;
                      profile.stats.attributes.favorite_itemwraps[i] =
                        itemToSlotID || body.itemToSlot;
                    }
                  }
                  changes.push({
                    changeType: "itemAttrChanged",
                    itemId: body.lockerItem,
                    attributeName: "locker_slots_data",
                    attributeValue: lockerItemObj.attributes.locker_slots_data,
                  });
                }
                break;
              }

              default: {
                const slot =
                  lockerItemObj.attributes.locker_slots_data.slots[
                    body.category
                  ];
                if (slot) {
                  slot.items = [body.itemToSlot];
                  profile.stats.attributes[
                    `favorite_${body.category}`.toLowerCase()
                  ] = itemToSlotID || body.itemToSlot;
                  changes.push({
                    changeType: "itemAttrChanged",
                    itemId: body.lockerItem,
                    attributeName: "locker_slots_data",
                    attributeValue: lockerItemObj.attributes.locker_slots_data,
                  });
                }
              }
            }

            profile.rvn++;
            profile.commandRevision++;
            profile.updated = new Date().toISOString();

            await userProfileDoc.updateOne({
              $set: { [`profiles.${profileId}`]: profile },
            });

            changes.push({ changeType: "fullProfileUpdate", profile });
          }
          break;

        case "SetCosmeticLockerBanner":
          {
            const body = await c.req.json();
            const rvn = Number(query.rvn || -1);

            if (profileId !== "athena") {
              return error.createError(
                c,
                "errors.com.epicgames.modules.profiles.invalid_command",
                `SetCosmeticLockerBanner is not valid on ${profileId} profile`,
                ["SetCosmeticLockerBanner", profileId],
                12801,
                undefined,
                400
              );
            }

            const revisionCheck =
              versionInfo.build >= 12.2 ? profile.commandRevision : profile.rvn;

            const requiredFields = [
              "lockerItem",
              "bannerIconTemplateName",
              "bannerColorTemplateName",
            ];
            const missing = requiredFields.filter(
              (field) => typeof body[field] !== "string"
            );
            if (missing.length > 0) {
              return error.createError(
                c,
                "errors.com.epicgames.validation.validation_failed",
                `Validation Failed. [${missing.join(", ")}] field(s) is missing.`,
                [`[${missing.join(", ")}]`],
                1040,
                undefined,
                400
              );
            }

            const {
              lockerItem,
              bannerIconTemplateName,
              bannerColorTemplateName,
            } = body;

            if (!profile.items || !profile.items[lockerItem]) {
              return error.createError(
                c,
                "errors.com.epicgames.fortnite.id_invalid",
                `Item (id: '${lockerItem}') not found`,
                [lockerItem],
                16027,
                undefined,
                400
              );
            }

            const item = profile.items[lockerItem];
            if (
              item.templateId.toLowerCase() !==
              "cosmeticlocker:cosmeticlocker_athena"
            ) {
              return error.createError(
                c,
                "errors.com.epicgames.fortnite.id_invalid",
                "lockerItem id is not a cosmeticlocker",
                ["lockerItem"],
                16027,
                undefined,
                400
              );
            }

            const commonProfile = (userProfileDoc.profiles as any)[
              "common_core"
            ];
            commonProfile.items ||= {};

            let iconId = "";
            let colorId = "";

            for (const [itemId, data] of Object.entries(
              commonProfile.items
            ) as [string, { templateId: string }][]) {
              const tid = data.templateId.toLowerCase();
              if (
                tid ===
                `homebasebannericon:${bannerIconTemplateName}`.toLowerCase()
              )
                iconId = itemId;
              if (
                tid ===
                `homebasebannercolor:${bannerColorTemplateName}`.toLowerCase()
              )
                colorId = itemId;
              if (iconId && colorId) break;
            }

            if (!iconId || !colorId) {
              return error.createError(
                c,
                "errors.com.epicgames.fortnite.item_not_found",
                !iconId
                  ? `Banner template 'HomebaseBannerIcon:${bannerIconTemplateName}' not found`
                  : `Banner template 'HomebaseBannerColor:${bannerColorTemplateName}' not found`,
                [],
                16006,
                undefined,
                400
              );
            }

            item.attributes.banner_icon_template = bannerIconTemplateName;
            item.attributes.banner_color_template = bannerColorTemplateName;
            profile.stats.attributes.banner_icon = bannerIconTemplateName;
            profile.stats.attributes.banner_color = bannerColorTemplateName;

            changes.push({
              changeType: "itemAttrChanged",
              itemId: lockerItem,
              attributeName: "banner_icon_template",
              attributeValue: bannerIconTemplateName,
            });

            changes.push({
              changeType: "itemAttrChanged",
              itemId: lockerItem,
              attributeName: "banner_color_template",
              attributeValue: bannerColorTemplateName,
            });

            if (changes.length > 0) {
              profile.rvn++;
              profile.commandRevision++;
              profile.updated = new Date().toISOString();

              await userProfileDoc.updateOne({
                $set: { [`profiles.${profileId}`]: profile },
              });
            }

            if (rvn !== revisionCheck) {
              changes.length = 0;
              changes.push({ changeType: "fullProfileUpdate", profile });
            }
          }
          break;

        case "MarkItemSeen":
          {
            const body = await c.req.json<{ itemIds: string[] }>();

            if (!profile.items) profile.items = {};

            for (const itemId of body.itemIds || []) {
              if (!profile.items[itemId]) continue;
              profile.items[itemId].attributes.item_seen = true;
              changes.push({
                changeType: "itemAttrChanged",
                itemId,
                attributeName: "item_seen",
                attributeValue: true,
              });
            }

            if (changes.length) {
              profile.rvn++;
              profile.commandRevision++;
              profile.updated = new Date().toISOString();
              await userProfileDoc.updateOne({
                $set: { [`profiles.${profileId}`]: profile },
              });
            }

            if (Number(query.rvn ?? -1) !== serverRvn) {
              changes.length = 0;
              changes.push({ changeType: "fullProfileUpdate", profile });
            }
          }
          break;
        case "SetItemFavoriteStatusBatch":
          {
            type ReqBody = {
              itemIds: string[];
              itemFavStatus: boolean[];
            };

            let requestData: ReqBody;

            try {
              requestData = await c.req.json<ReqBody>();
            } catch {
              return error.createError(
                c,
                "errors.com.epicgames.validation.invalid_request",
                "Invalid JSON payload",
                [],
                1040,
                undefined,
                400
              );
            }

            const missingFields: string[] = [];
            if (!("itemIds" in requestData)) missingFields.push("itemIds");
            if (!("itemFavStatus" in requestData))
              missingFields.push("itemFavStatus");
            if (missingFields.length) {
              return error.createError(
                c,
                "errors.com.epicgames.validation.missing_fields",
                `Missing required field(s): ${missingFields.join(", ")}`,
                missingFields,
                1040,
                undefined,
                400
              );
            }

            if (!profile.items) profile.items = {};

            for (let i = 0; i < requestData.itemIds.length; i++) {
              const itemId = requestData.itemIds[i];
              const favStatus = requestData.itemFavStatus[i];

              if (!itemId || !profile.items[itemId]) continue;
              if (typeof favStatus !== "boolean") continue;

              profile.items[itemId].attributes.favorite = favStatus;
              changes.push({
                changeType: "itemAttrChanged",
                itemId,
                attributeName: "favorite",
                attributeValue: favStatus,
              });
            }

            if (changes.length) {
              profile.rvn++;
              profile.commandRevision++;
              profile.updated = new Date().toISOString();

              await userProfileDoc.updateOne({
                $set: { [`profiles.${profileId}`]: profile },
              });
            }

            changes.push({ changeType: "fullProfileUpdate", profile });
          }
          break;
        case "CopyCosmeticLoadout": {
          const body = await c.req.json<{
            sourceIndex: number;
            targetIndex?: number;
            optNewNameForTarget?: string;
          }>();

          if (!profile.items) profile.items = {};

          if (body.sourceIndex === 0) {
            const targetKey = `Fortnite${body.targetIndex}-loadout`;
            profile.items[targetKey] = profile.items["Frost-loadout"];
            profile.items[targetKey].attributes.locker_name =
              body.optNewNameForTarget;
            profile.stats.attributes.loadouts[body.targetIndex!] = targetKey;

            profile.rvn++;
            profile.commandRevision++;
            profile.updated = new Date().toISOString();
            await userProfileDoc.updateOne({
              $set: { [`profiles.${profileId}`]: profile },
            });
          } else {
            const sourceKey = `Fortnite${body.sourceIndex}-loadout`;
            const item = profile.items[sourceKey];
            if (!item) {
              return error.createError(
                c,
                "errors.com.epicgames.modules.profiles.operation_forbidden",
                `Locker item ${sourceKey} not found`,
                [profileId],
                12813,
                undefined,
                403
              );
            }

            profile.stats.attributes.active_loadout_index = body.sourceIndex;
            profile.stats.attributes.last_applied_loadout = sourceKey;
            profile.items["Frost-loadout"].attributes.locker_slots_data =
              item.attributes.locker_slots_data;

            profile.rvn++;
            profile.commandRevision++;
            profile.updated = new Date().toISOString();
            await userProfileDoc.updateOne({
              $set: { [`profiles.${profileId}`]: profile },
            });
          }

          changes.push({ changeType: "fullProfileUpdate", profile });
          break;
        }
        case "SetCosmeticLockerName": {
          const body = await c.req.json<{ lockerItem: string; name: string }>();

          if (!profile.items) profile.items = {};

          const item = profile.items[body.lockerItem];
          if (!item) {
            return error.createError(
              c,
              "errors.com.epicgames.modules.profiles.operation_forbidden",
              `Locker item ${body.lockerItem} not found`,
              [profileId],
              12813,
              undefined,
              403
            );
          }

          if (
            typeof body.name === "string" &&
            item.attributes.locker_name !== body.name
          ) {
            item.attributes.locker_name = body.name;

            changes.push({ changeType: "fullProfileUpdate", profile });

            profile.rvn++;
            profile.commandRevision++;
            profile.updated = new Date().toISOString();

            await userProfileDoc.updateOne({
              $set: { [`profiles.${profileId}`]: profile },
            });
          }

          changes.push({ changeType: "fullProfileUpdate", profile });
          break;
        }
        case "DeleteCosmeticLoadout": {
          const body = await c.req.json<{
            index: number;
            fallbackLoadoutIndex: number;
            leaveNullSlot?: boolean;
          }>();

          if (!profile.items) profile.items = {};

          const loadoutKey = `Fortnite${body.index}-loadout`;

          if (body.leaveNullSlot !== false) {
            if (body.fallbackLoadoutIndex === -1) {
              delete profile.items[loadoutKey];
              delete profile.stats.attributes.loadouts[body.index];
            } else {
              const fallbackKey =
                profile.stats.attributes.loadouts[body.fallbackLoadoutIndex];

              profile.stats.attributes.last_applied_loadout = fallbackKey;
              profile.stats.attributes.active_loadout_index =
                body.fallbackLoadoutIndex;
              profile.items["Frost-loadout"].attributes.locker_slots_data =
                profile.items[fallbackKey].attributes.locker_slots_data;

              delete profile.items[loadoutKey];
              delete profile.stats.attributes.loadouts[body.index];
            }
          }

          profile.rvn++;
          profile.commandRevision++;
          profile.updated = new Date().toISOString();

          await userProfileDoc.updateOne({
            $set: { [`profiles.${profileId}`]: profile },
          });

          changes.push({ changeType: "fullProfileUpdate", profile });

          break;
        }
        case "SetRandomCosmeticLoadoutFlag": {
          const body = await c.req.json<{ random: boolean }>();
          const isRandom = body.random;

          if (!profile.items) profile.items = {};
          if (!profile.stats.attributes.loadouts)
            profile.stats.attributes.loadouts = {};

          if (isRandom) {
            const loadoutKeys = Object.entries(
              profile.stats.attributes.loadouts
            )
              .filter(([index, key]) => key && key !== "Frost-loadout")
              .map(([index, key]) => key);

            if (loadoutKeys.length > 0) {
              const randomKey =
                loadoutKeys[Math.floor(Math.random() * loadoutKeys.length)];
              const randomLoadout = profile.items[
                randomKey as keyof typeof profile.items
              ] as any;

              if (randomLoadout) {
                profile.items["Frost-loadout"].attributes.locker_slots_data =
                  randomLoadout.attributes.locker_slots_data;

                profile.stats.attributes.active_loadout_index = Number(
                  Object.keys(profile.stats.attributes.loadouts).find(
                    (key) =>
                      profile.stats.attributes.loadouts[key] === randomKey
                  ) || 0
                );
                profile.stats.attributes.last_applied_loadout = randomKey;
              }
            }
          }

          profile.rvn++;
          profile.commandRevision++;
          profile.updated = new Date().toISOString();
          await userProfileDoc.updateOne({
            $set: { [`profiles.${profileId}`]: profile },
          });

          changes.push({ changeType: "fullProfileUpdate", profile });
          break;
        }
        case "PurchaseCatalogEntry": {
          const body = await c.req.json<{
            offerId: string;
            purchaseQuantity?: number;
          }>();

          if (!body.offerId) {
            return error.createError(
              c,
              "errors.com.epicgames.validation.validation_failed",
              "Missing offerId",
              ["offerId"],
              1040,
              undefined,
              400
            );
          }

          const profile = (userProfileDoc.profiles as any)[profileId];
          const athena = (userProfileDoc.profiles as any)["athena"];
          const baseRevision = profile.rvn;
          let notifications: any[] = [];
          let changes: any[] = [];
          let lootList: any[] = [];

          let multiUpdate = [
            {
              profileId: "athena",
              profileRevision: athena.rvn || 0,
              profileChangesBaseRevision: athena.rvn || 0,
              profileChanges: [],
              profileCommandRevision: athena.commandRevision || 0,
            },
          ];

          const offer = await shop.getOfferID(body.offerId, versionInfo.build);
          if (!offer) {
            return error.createError(
              c,
              "errors.com.epicgames.fortnite.id_invalid",
              `Offer ${body.offerId} not found`,
              [body.offerId],
              16027,
              undefined,
              400
            );
          }

          const season = versionInfo.season;
          const battlePassPath = path.join(
            __dirname,
            "../../static/BattlePass/",
            `S${season}.json`
          );
          let battlePassData: any = null;
          if (!fs.existsSync(battlePassPath)) {
            return error.createError(
              c,
              "com.epicgames.common.battlepass.not_found",
              "No battle pass data found for this season",
              [],
              404,
              undefined,
              404
            );
          }

          battlePassData = JSON.parse(fs.readFileSync(battlePassPath, "utf8"));
          const purchaseQty = body.purchaseQuantity || 1;
          const pricePerUnit = offer.offerId.prices?.[0]?.finalPrice || 0;
          const totalCost = pricePerUnit * purchaseQty;
          const offerId = body.offerId;
          let isBPPurchase = false;

          if (
            offer.offerId.prices?.[0]?.currencyType.toLowerCase() ===
            "mtxcurrency"
          ) {
            let paid = false;
            for (const key in profile.items) {
              const item = profile.items[key];
              if (!item.templateId.toLowerCase().startsWith("currency:mtx"))
                continue;

              const platform = item.attributes.platform.toLowerCase();
              if (
                platform !==
                  profile.stats.attributes.current_mtx_platform.toLowerCase() &&
                platform !== "shared"
              )
                continue;

              if (item.quantity < totalCost) {
                return error.createError(
                  c,
                  "errors.com.epicgames.currency.mtx.insufficient",
                  `Not enough MTX currency (${totalCost})`,
                  [`${totalCost}`, `${item.quantity}`],
                  1040,
                  undefined,
                  400
                );
              }

              item.quantity -= totalCost;
              changes.push({
                changeType: "itemQuantityChanged",
                itemId: key,
                quantity: item.quantity,
              });
              paid = true;
              break;
            }
            if (!paid && totalCost > 0) {
              return error.createError(
                c,
                "errors.com.epicgames.currency.mtx.insufficient",
                `Not enough MTX currency (${totalCost})`,
                [`${totalCost}`],
                1040,
                undefined,
                400
              );
            }
          }

          if (battlePassData) {
            const isBattlePass = [
              battlePassData.battlePassOfferId,
              battlePassData.battleBundleOfferId,
            ].includes(offerId);
            const isTierOffer = offerId === battlePassData.tierOfferId;

            if (isBattlePass) {
              isBPPurchase = true;
              lootList.push(
                ...(await handleBattlePassPurchase(
                  athena,
                  profile,
                  userProfileDoc,
                  battlePassData,
                  offerId,
                  season,
                  changes,
                  multiUpdate
                ))
              );
            } else if (isTierOffer) {
              isBPPurchase = true;
              lootList.push(
                ...(await handleTierPurchase(
                  athena,
                  profile,
                  userProfileDoc,
                  battlePassData,
                  body,
                  changes,
                  multiUpdate
                ))
              );
            }
          }

          if (/^BR(Daily|Weekly|Season)Storefront$/.test(offer.name)) {
            lootList.push(
              ...(await handleCatalogPurchase(
                athena,
                offer,
                multiUpdate,
                error,
                c
              ))
            );
          }

          if (isBPPurchase) {
            const giftBoxId = MakeID();

            profile.items[giftBoxId] = {
              templateId: athena.stats.attributes.book_purchased
                ? "GiftBox:gb_battlepass"
                : "GiftBox:gb_battlepasspurchased",
              attributes: { fromAccountId: "", lootList },
              quantity: 1,
            };

            changes.push({
              changeType: "itemAdded",
              itemId: giftBoxId,
              item: profile.items[giftBoxId],
            });

            notifications.push({
              type: "CatalogPurchase",
              primary: true,
              lootResult: { items: lootList },
            });
          } else {
            notifications.push({
              type: "CatalogPurchase",
              primary: true,
              lootResult: { items: lootList },
            });
          }

          athena.rvn++;
          athena.commandRevision++;
          athena.updated = new Date().toISOString();
          multiUpdate[0]!.profileRevision = athena.rvn;
          multiUpdate[0]!.profileCommandRevision = athena.commandRevision;
          profile.rvn++;
          profile.commandRevision++;
          profile.updated = new Date().toISOString();

          await userProfileDoc.updateOne({
            $set: {
              [`profiles.${profileId}`]: profile,
              ["profiles.athena"]: athena,
            },
          });

          return c.json({
            profileRevision: profile.rvn,
            profileId,
            profileChangesBaseRevision: baseRevision,
            profileChanges: changes,
            notifications,
            profileCommandRevision: profile.commandRevision,
            serverTime: new Date().toISOString(),
            multiUpdate,
            responseVersion: 1,
          });
        }
        case "RefundMtxPurchase": {
          const body = await c.req.json<{ purchaseId?: string }>();
          const athena = (userProfileDoc.profiles as any).athena;
          const baseRevision = profile.rvn || 0;

          const changes: any[] = [];
          const multiUpdate = [
            {
              profileId: "athena",
              profileRevision: athena.rvn || 0,
              profileChangesBaseRevision: athena.rvn || 0,
              profileChanges: [] as any[],
              profileCommandRevision: athena.commandRevision || 0,
            },
          ];

          const ItemGuids: string[] = [];

          if (body.purchaseId) {
            profile.stats.attributes.mtx_purchase_history.refundsUsed += 1;
            profile.stats.attributes.mtx_purchase_history.refundCredits -= 1;

            for (const purchase of profile.stats.attributes.mtx_purchase_history
              .purchases) {
              if (purchase.purchaseId === body.purchaseId) {
                for (const loot of purchase.lootResult) {
                  ItemGuids.push(loot.itemGuid);
                }
                purchase.refundDate = new Date().toISOString();

                for (const key in profile.items) {
                  const item = profile.items[key];
                  if (
                    item.templateId.toLowerCase().startsWith("currency:mtx")
                  ) {
                    const platform = item.attributes.platform.toLowerCase();
                    if (
                      platform ===
                        profile.stats.attributes.current_mtx_platform.toLowerCase() ||
                      platform === "shared"
                    ) {
                      item.quantity += purchase.totalMtxPaid;
                      changes.push({
                        changeType: "itemQuantityChanged",
                        itemId: key,
                        quantity: item.quantity,
                      });
                      break;
                    }
                  }
                }
              }
            }

            for (const guid of ItemGuids) {
              if (athena.items[guid]) {
                delete athena.items[guid];
                multiUpdate[0]!.profileChanges.push({
                  changeType: "itemRemoved",
                  itemId: guid,
                });
              }
            }

            athena.rvn++;
            athena.commandRevision++;
            profile.rvn++;
            profile.commandRevision++;
          }

          if (changes.length) {
            changes.push({
              changeType: "statModified",
              name: "mtx_purchase_history",
              value: profile.stats.attributes.mtx_purchase_history,
            });
            multiUpdate[0]!.profileRevision = athena.rvn;
            multiUpdate[0]!.profileCommandRevision = athena.commandRevision;

            await userProfileDoc.updateOne({
              $set: {
                [`profiles.${profileId}`]: profile,
                ["profiles.athena"]: athena,
              },
            });
          }

          return c.json({
            profileRevision: profile.rvn,
            profileId,
            profileChangesBaseRevision: baseRevision,
            profileChanges: changes,
            profileCommandRevision: profile.commandRevision,
            serverTime: new Date().toISOString(),
            multiUpdate,
            responseVersion: 1,
          });
        }
        default:
          changes.push({ changeType: "fullProfileUpdate", profile });
          break;
      }

      return c.json({
        profileRevision: profile.rvn,
        profileId,
        profileChangesBaseRevision: baseRevision,
        profileChanges: changes,
        profileCommandRevision: profile.commandRevision,
        serverTime: new Date().toISOString(),
        responseVersion: 1,
      });
    }
  );
};
