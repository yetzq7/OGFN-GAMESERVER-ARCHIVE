export {};

declare global {
  namespace NodeJS {
    interface Global {
      authorizationCodes: Array<{ accountId: string; code: string }>;
      exchangeCodes: Array<{ accountId: string; code: string }>;
    }
  }
}
