import { Schema, model, Document } from "mongoose";

export interface IDeviceAuth extends Document {
  deviceId: string;
  accountId: string;
  secret: string;
  userAgent: string;
  created: {
    location: string;
    ipAddress: string;
    dateTime: Date;
  };
}

const DeviceAuthSchema = new Schema<IDeviceAuth>(
  {
    deviceId: { type: String, required: true },
    accountId: { type: String, required: true },
    secret: { type: String, required: true },
    userAgent: { type: String, required: true },
    created: {
      location: { type: String, required: true },
      ipAddress: { type: String, required: true },
      dateTime: { type: Date, default: Date.now },
    },
  },
  { timestamps: true }
);

DeviceAuthSchema.index({ deviceId: 1, accountId: 1 }, { unique: true });

export const DeviceAuth = model<IDeviceAuth>("DeviceAuth", DeviceAuthSchema);
