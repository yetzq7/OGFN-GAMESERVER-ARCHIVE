import { Schema, model, Document } from "mongoose";

export interface ITokenStore extends Document {
  accountId: string;
  accessToken: string;
  refreshToken: string;
}

const TokenStoreSchema = new Schema<ITokenStore>(
  {
    accountId: { type: String, required: true, unique: true },
    accessToken: { type: String, required: true },
    refreshToken: { type: String, required: true },
  },
  { timestamps: true }
);

export const TokenStore = model<ITokenStore>("TokenStore", TokenStoreSchema);
