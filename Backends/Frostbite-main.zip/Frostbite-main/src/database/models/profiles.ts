import { Schema, Document, model } from "mongoose"

export interface IProfiles extends Document {
  accountId: string
  profiles: Object
}

const ProfilesSchema = new Schema<IProfiles>(
  {
    accountId: { type: String, required: true, unique: true },
    profiles: { type: Object, required: true },
  },
  {
    collection: "profiles",
  }
)

export default model<IProfiles>("Profiles", ProfilesSchema)