import mongoose from "mongoose";
import { Logger } from "../utils/logger";

export async function InitDB() {
    const uri = process.env.MONGO_URI!;

    try {
        await mongoose.connect(uri, { serverSelectionTimeoutMS: 10000 });
        Logger.MongoDB(`Connection to ${uri} successfully established.`);
    } catch (err) {
        Logger.Error("MongoDB connection failed: " + (err as Error).message);
        process.exit(1);
    }
}