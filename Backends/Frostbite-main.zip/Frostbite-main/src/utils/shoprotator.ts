import axios from "axios";
import fs from "fs";
import path from "path";

const fortniteapi = "https://fortnite-api.com/v2/cosmetics/br";
const battlepassDirectory = path.join(__dirname, "../../static/BattlePass");
const shopJSONv1 = path.join(
  __dirname,
  "../../static/shop/catalog_config.json"
);
const shopJSONv2 = path.join(
  __dirname,
  "../../static/shop/catalog_configV2.json"
);

const iconFile = path.join(__dirname, "../../static/shop/sections/icons.json");
const iconBundles = JSON.parse(fs.readFileSync(iconFile, "utf-8"));

interface Cosmetic {
  id: string;
  name: string;
  rarity?: { displayValue?: string };
  type?: { value: string };
  series?: { value: string };
  introduction?: { chapter?: string; season?: string };
}

async function fetchItems(): Promise<Cosmetic[]> {
  const files = fs.readdirSync(battlepassDirectory);
  const excludedItemIds = new Set();

  for (const file of files) {
    if (/season[2]/i.test(file)) continue;
    try {
      const data = JSON.parse(
        fs.readFileSync(path.join(battlepassDirectory, file), "utf-8")
      );
      [...data.paidRewards, ...data.freeRewards].forEach((reward: any) => {
        Object.keys(reward).forEach((rawId) => {
          const itemId = rawId.split(":")[1]?.toLowerCase();
          if (itemId) excludedItemIds.add(itemId);
        });
      });
    } catch {}
  }

  for (const entry of iconBundles) {
    for (const grant of entry.itemGrants) {
      const id = grant.split(":")[1]?.toLowerCase();
      if (id) excludedItemIds.add(id);
    }
  }

  const response = await axios.get(fortniteapi);
  const cosmetics: Cosmetic[] = response.data.data || [];

  return cosmetics.filter((item) => {
    const id = item.id?.toLowerCase();
    const { chapter, season } = item.introduction || {};
    const rarity = item.rarity?.displayValue?.toLowerCase();
    const type = item.type?.value?.toLowerCase();
    const versionCheck =
      process.env.VERSION && parseFloat(process.env.VERSION) <= 14.3
        ? !/(loadingscreen|music)/i.test(type || "")
        : true;

    return (
      !excludedItemIds.has(id) &&
      chapter === process.env.CHAPTER &&
      season &&
      !isNaN(parseInt(season)) &&
      parseInt(season) <= Number(process.env.SEASONLIMIT) &&
      rarity !== "common" &&
      !/(emoji)/i.test(type || "") &&
      !(type === "emote" && rarity === "legendary") &&
      versionCheck
    );
  });
}

function formatItemGrant(item: Cosmetic) {
  const typeValue = item.type?.value.toLowerCase() || "";
  const capitalized = typeValue.charAt(0).toUpperCase() + typeValue.slice(1);
  let typeMap = "";

  switch (typeValue) {
    case "outfit":
      typeMap = "AthenaCharacter";
      break;
    case "emote":
      typeMap = "AthenaDance";
      break;
    case "wrap":
      typeMap = "AthenaItemWrap";
      break;
    case "music":
      typeMap = "AthenaMusicPack";
      break;
    default:
      typeMap = `Athena${capitalized}`;
      break;
  }

  return [`${typeMap}:${item.id}`];
}

function getPrice(item: Cosmetic) {
  const rarity = item.rarity?.displayValue?.toLowerCase();
  const type = item.type?.value?.toLowerCase();
  const series = item.series?.value?.toLowerCase();

  if (type === "music" || type === "loadingscreen") return 200;

  const priceMap: Record<string, number> = {
    outfit_legendary: 2000,
    outfit_epic: 1500,
    outfit_rare: 1200,
    outfit_uncommon: 800,
    pickaxe_epic: 1200,
    pickaxe_rare: 800,
    pickaxe_uncommon: 500,
    backpack_legendary: 800,
    backpack_epic: 500,
    backpack_rare: 400,
    backpack_uncommon: 200,
    emote_epic: 800,
    emote_rare: 500,
    emote_uncommon: 200,
    glider_legendary: 2000,
    glider_epic: 1200,
    glider_rare: 800,
    glider_uncommon: 500,
    wrap_epic: 700,
    wrap_rare: 500,
    wrap_uncommon: 300,
    loadingscreen_common: 200,
    loadingscreen_uncommon: 200,
    music_common: 200,
  };

  if (series) {
    const special = {
      "gaming legends series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 700,
      },
      "marvel series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 700,
      },
      "star wars series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 700,
      },
      "dc series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 700,
      },
      "icon series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 700,
      },
      "crew series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
      "slurp series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
      "lava series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
      "frozen series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
      "shadow series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
      "dark series": {
        outfit: 1500,
        pickaxe: 800,
        backpack: 500,
        emote: 500,
        glider: 500,
        wrap: 500,
      },
    } as Record<string, Record<string, number>>;

    if (type === "backpack") return special[series]?.[type] ?? 400;

    return special[series]?.[type || ""] ?? 999999;
  }

  return priceMap[`${type}_${rarity}`] ?? (type === "backpack" ? 400 : 999999);
}

function pickRandom(items: Cosmetic[], count: number) {
  return [...items].sort(() => Math.random() - 0.5).slice(0, count);
}

export async function rotateShop() {
  const cosmetics = await fetchItems();
  if (cosmetics.length === 0) return false;

  const version = parseFloat(process.env.VERSION || "0");
  const usedIds = new Set<string>();
  const chance = 0.8;
  const skipSpecialSeriesChance = 0.7;

  if (version < 14.3) {
    const dailyPool = cosmetics.filter(
      (c) =>
        c.type?.value.toLowerCase() !== "music" &&
        c.type?.value.toLowerCase() !== "loadingscreen"
    );
    const featuredPool = [...dailyPool];

    const dailySkins = dailyPool.filter(
      (c) => c.type?.value.toLowerCase() === "outfit"
    );
    const featuredSkins = featuredPool.filter(
      (c) => c.type?.value.toLowerCase() === "outfit"
    );

    const dailyChosenSkins = pickRandom(
      dailySkins,
      Math.min(2, dailySkins.length)
    );
    const featuredChosenSkins = pickRandom(
      featuredSkins,
      Math.min(2, featuredSkins.length)
    );

    dailyChosenSkins.forEach((item) => usedIds.add(item.id));
    featuredChosenSkins.forEach((item) => usedIds.add(item.id));

    const dailyRemaining = pickRandom(
      dailyPool.filter((c) => !usedIds.has(c.id)),
      8 - dailyChosenSkins.length
    );
    const featuredRemaining = pickRandom(
      featuredPool.filter((c) => !usedIds.has(c.id)),
      8 - featuredChosenSkins.length
    );

    dailyRemaining.forEach((item) => usedIds.add(item.id));
    featuredRemaining.forEach((item) => usedIds.add(item.id));

    const payload: any[] = [
      ...dailyChosenSkins.concat(dailyRemaining).map((i) => ({
        section: "Daily",
        itemGrants: formatItemGrant(i),
        price: getPrice(i),
      })),
      ...featuredChosenSkins.concat(featuredRemaining).map((i) => ({
        section: "Featured",
        itemGrants: formatItemGrant(i),
        price: getPrice(i),
      })),
    ];

    fs.writeFileSync(shopJSONv1, JSON.stringify(payload, null, 2), "utf-8");
    return false;
  }

  const sections: string[] = [
    "Daily",
    "Featured",
    "Backpack",
    "Dance",
    "Music",
    "Wraps",
  ];
  const output: any[] = [];

  const specialSeries = [
    "marvel series",
    "dc series",
    "gaming legends series",
    "star wars series",
  ];
  const seriesNameMap: Record<string, string> = {
    "marvel series": "MARVEL",
    "dc series": "DC",
    "gaming legends series": "GAMING",
    "star wars series": "STAR WARS",
  };

  if (Math.random() > skipSpecialSeriesChance) {
    specialSeries.forEach((series) => {
      if (Math.random() > chance) return;
      const pool = cosmetics.filter(
        (c) => c.series?.value?.toLowerCase() === series && !usedIds.has(c.id)
      );
      if (pool.length === 0) return;
      const chosen = pickRandom(pool, Math.min(8, pool.length));
      chosen.forEach((item) => {
        usedIds.add(item.id);
        output.push({
          section: seriesNameMap[series],
          itemGrants: formatItemGrant(item),
          price: getPrice(item),
        });
      });
    });
  }

  sections.forEach((section) => {
    if (section === "Icon") return;

    let typeFilter = "";
    switch (section) {
      case "Backpack":
        typeFilter = "backpack";
        break;
      case "Dance":
        typeFilter = "emote";
        break;
      case "Music":
        typeFilter = "music";
        break;
      case "Wraps":
        typeFilter = "wrap";
        break;
    }

    let pool = typeFilter
      ? cosmetics.filter(
          (c) =>
            c.type?.value?.toLowerCase() === typeFilter && !usedIds.has(c.id)
        )
      : cosmetics.filter((c) => !usedIds.has(c.id));

    if (section === "Daily" || section === "Featured") {
      pool = pool.filter(
        (c) =>
          c.type?.value.toLowerCase() !== "music" &&
          c.type?.value.toLowerCase() !== "loadingscreen"
      );
      const skinsPool = pool.filter(
        (c) => c.type?.value.toLowerCase() === "outfit"
      );
      const chosenSkins = pickRandom(skinsPool, Math.min(2, skinsPool.length));
      chosenSkins.forEach((item) => usedIds.add(item.id));
      pool = pool.filter((c) => !usedIds.has(c.id));
      const chosenRemaining = pickRandom(pool, 8 - chosenSkins.length);
      chosenRemaining.forEach((item) => usedIds.add(item.id));
      output.push(
        ...chosenSkins.concat(chosenRemaining).map((i) => ({
          section,
          itemGrants: formatItemGrant(i),
          price: getPrice(i),
        }))
      );
      return;
    }

    const count = 16;
    const chosen = pickRandom(pool, count);
    chosen.forEach((item) => {
      usedIds.add(item.id);
      output.push({
        section,
        itemGrants: formatItemGrant(item),
        price: getPrice(item),
      });
    });
  });

  const availableIcons = iconBundles.filter((bundle: any) =>
    bundle.itemGrants.every((g: string) => !usedIds.has(g.split(":")[1]!))
  );
  if (iconBundles && availableIcons.length > 0 && Math.random() <= chance) {
    output.push(...availableIcons);
  }

  fs.writeFileSync(shopJSONv2, JSON.stringify(output, null, 2), "utf-8");
  return true;
}
