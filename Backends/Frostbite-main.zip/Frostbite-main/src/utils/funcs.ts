import { Hono, type HonoRequest, type Context, type Next } from "hono";
import { v4 as uuidv4 } from "uuid";
import { type IUser } from "../database/models/user";
import * as error from "./error";
import fs from "fs";
import path from "path";
import url from "url";
import jwt from "jsonwebtoken";
import { TokenStore } from "../database/models/tokens";

export async function loadRoutes(app: Hono) {
  const routesPath = path.join(
    path.dirname(url.fileURLToPath(import.meta.url)),
    "../routes"
  );
  const files = fs.readdirSync(routesPath);

  for (const file of files) {
    if (!file.endsWith(".ts")) continue;

    const modulePath = path.join(routesPath, file);
    const routeModule = await import(url.pathToFileURL(modulePath).toString());
    const route = routeModule.default;

    if (!route) continue;

    if (typeof route === "function") {
      route(app);
    } else if (route instanceof Hono) {
      app.route("/", route);
    }
  }
}

export function GetVersionInfo(req: HonoRequest): {
  season: number;
  build: number;
  CL: string;
  lobby: string;
} {
  const memory = {
    season: 0,
    build: 0.0,
    CL: "0",
    lobby: "",
  };

  const userAgent = req.header("user-agent");
  if (!userAgent) return memory;

  let CL = "";

  try {
    let BuildID = userAgent.split("-")[3]?.split(",")[0];

    if (BuildID && !Number.isNaN(Number(BuildID))) {
      CL = BuildID;
    } else {
      BuildID = userAgent.split("-")[3]?.split(" ")[0];

      if (BuildID && !Number.isNaN(Number(BuildID))) CL = BuildID;
    }
  } catch {
    try {
      let BuildID = userAgent.split("-")[1]?.split("+")[0];

      if (BuildID && !Number.isNaN(Number(BuildID))) CL = BuildID;
    } catch {}
  }

  try {
    let Build = userAgent.split("Release-")[1]?.split("-")[0] ?? "";

    if (Build.split(".").length === 3) {
      const Value = Build.split(".");
      Build = `${Value[0]}.${Value[1]}${Value[2]}`;
    }

    memory.season = Number(Build.split(".")[0]);
    memory.build = Number(Build);
    memory.CL = CL;
    memory.lobby = `LobbySeason${memory.season}`;

    if (Number.isNaN(memory.season)) throw new Error();
  } catch {}

  return memory;
}

export function MakeID() {
  return uuidv4().replace(/-/g, "");
}

// Tokens stuff
interface TokenPayload {
  p?: string;
  clsvc?: string;
  t?: string;
  mver?: boolean;
  clid?: string;
  ic?: boolean;
  am?: string;
  jti?: string;
  creation_date: Date;
  hours_expire: number;
  app?: string;
  sub?: string;
  dvid?: string;
  dn?: string;
  iai?: string;
  sec?: number;
}

export function createClient(
  clientId: string,
  grant_type: string,
  expiresIn: number
): string {
  const clientToken = jwt.sign(
    {
      p: Buffer.from(MakeID()).toString("base64"),
      clsvc: "fortnite",
      t: "s",
      mver: false,
      clid: clientId,
      ic: true,
      am: grant_type,
      jti: MakeID(),
      creation_date: new Date(),
      hours_expire: expiresIn,
    },
    process.env.JWT_SECRET as string,
    { expiresIn: `${expiresIn}h` }
  );

  return clientToken;
}

export function createAccess(
  user: IUser | null,
  clientId: string,
  grant_type: string,
  deviceId: string,
  expiresIn: number
): string {
  if (!user) throw new Error("User is null");
  const accessToken = jwt.sign(
    {
      app: "fortnite",
      sub: user.accountId,
      dvid: deviceId,
      mver: false,
      clid: clientId,
      dn: user.username,
      am: grant_type,
      p: Buffer.from(MakeID()).toString("base64"),
      iai: user.accountId,
      sec: 1,
      clsvc: "fortnite",
      t: "s",
      ic: true,
      jti: MakeID(),
      creation_date: new Date(),
      hours_expire: expiresIn,
    },
    process.env.JWT_SECRET as string,
    { expiresIn: `${expiresIn}h` }
  );

  return accessToken;
}

export function createRefresh(
  user: IUser | null,
  clientId: string,
  grant_type: string,
  deviceId: string,
  expiresIn: number
): string {
  if (!user) throw new Error("User is null");
  const refreshToken = jwt.sign(
    {
      sub: user.accountId,
      dvid: deviceId,
      t: "r",
      clid: clientId,
      am: grant_type,
      jti: MakeID(),
      creation_date: new Date(),
      hours_expire: expiresIn,
    },
    process.env.JWT_SECRET as string,
    { expiresIn: `${expiresIn}h` }
  );

  return refreshToken;
}

export async function verifyToken(c: Context, next: Next) {
  const authErr = () =>
    error.createError(
      c,
      "errors.com.epicgames.common.authorization.authorization_failed",
      `Authorization failed for ${c.req.url}`,
      [c.req.url],
      1032,
      undefined,
      401
    );

  const authHeader = c.req.header("authorization");
  if (!authHeader || !authHeader.toLowerCase().startsWith("bearer")) {
    return authErr();
  }

  const token = authHeader.slice("bearer ".length);

  try {
    const decodedToken = jwt.decode(token) as TokenPayload | null;
    if (!decodedToken) return authErr();

    const foundToken = await TokenStore.findOne({ accessToken: token }).lean();
    if (!foundToken) return authErr();

    const creationDate =
      typeof decodedToken.creation_date === "string"
        ? new Date(decodedToken.creation_date)
        : decodedToken.creation_date;

    const expiry =
      creationDate.getTime() + decodedToken.hours_expire * 60 * 60 * 1000;

    if (expiry <= Date.now()) {
      await TokenStore.deleteOne({ accessToken: token });
      return authErr();
    }

    await next();
  } catch {
    await TokenStore.deleteOne({ accessToken: token });
    return authErr();
  }
}

export function createProfiles(accountId: string): Record<string, any> {
  const profiles: Record<string, any> = {};
  const defaultProfilesPath = path.join(__dirname, "../../static/profiles");

  fs.readdirSync(defaultProfilesPath).forEach((fileName) => {
    const filePath = path.join(defaultProfilesPath, fileName);
    const profile = JSON.parse(fs.readFileSync(filePath, "utf-8"));

    profile.accountId = accountId;
    profile.created = new Date().toISOString();
    profile.updated = new Date().toISOString();

    profiles[profile.profileId] = profile;
  });

  return profiles;
}
