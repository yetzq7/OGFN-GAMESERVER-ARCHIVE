import fs from "fs";
import path from "path";
import crypto from "crypto";
import { Logger } from "./logger";

interface ItemGrant {
  templateId: string;
  quantity: number;
}

interface Requirement {
  requirementType: string;
  requiredId: string;
  minQuantity: number;
}

interface Price {
  currencyType: string;
  currencySubType: string;
  regularPrice: number;
  finalPrice: number;
  saleExpiration: string;
  basePrice: number;
}

interface MetaInfo {
  key: string;
  value: string;
}

interface CatalogEntry {
  devName: string;
  offerId: string;
  fulfillmentIds: string[];
  dailyLimit: number;
  weeklyLimit: number;
  monthlyLimit: number;
  categories: string[];
  prices: Price[];
  meta: {
    NewDisplayAssetPath: string;
    SectionId: string;
    TileSize: string;
  };
  matchFilter: string;
  filterWeight: number;
  appStoreId: any[];
  requirements: Requirement[];
  offerType: string;
  giftInfo: {
    bIsEnabled: boolean;
    forcedGiftBoxTemplateId: string;
    purchaseRequirements: any[];
    giftRecordIds: any[];
  };
  refundable: boolean;
  metaInfo: MetaInfo[];
  displayAssetPath: string;
  itemGrants: ItemGrant[];
  sortPriority: number;
  catalogGroupPriority: number;
}

interface CatalogStorefront {
  name: string;
  catalogEntries: CatalogEntry[];
}

interface Catalog {
  storefronts: CatalogStorefront[];
}

interface CatalogConfigEntry {
  section?: string;
  itemGrants: string[];
  price: number;
}

interface CatalogConfig {
  [key: string]: CatalogConfigEntry;
}

// Shop below 14.30
export function getItemShop(): Catalog {
  const catalogPath = path.join(
    __dirname,
    "..",
    "..",
    "static",
    "shop",
    "catalog.json"
  );
  const catalogConfigPath = path.join(
    __dirname,
    "..",
    "..",
    "static",
    "shop",
    "catalog_config.json"
  );

  const catalog: Catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
  const CatalogConfig: CatalogConfig = JSON.parse(
    fs.readFileSync(catalogConfigPath, "utf8")
  );

  const dailyKeys = Object.keys(CatalogConfig).filter((k) =>
    k.toLowerCase().startsWith("daily")
  );
  const featuredKeys = Object.keys(CatalogConfig).filter((k) =>
    k.toLowerCase().startsWith("featured")
  );

  const featuredAssignments: Record<string, string[]> = {};
  const dailyAssignments: Record<string, string[]> = {};

  if (dailyKeys.length === 7) {
    dailyAssignments["daily1"] = ["daily1"];
    dailyAssignments["daily2"] = ["daily1"];
    dailyAssignments["daily3"] = [];
    dailyAssignments["daily4"] = [];
    dailyAssignments["daily5"] = [];
    dailyAssignments["daily6"] = [];
    dailyAssignments["daily7"] = [];
  } else if (dailyKeys.length === 8) {
    dailyAssignments["daily1"] = ["daily1"];
    dailyAssignments["daily2"] = ["daily1"];
    dailyAssignments["daily3"] = [];
    dailyAssignments["daily4"] = [];
    dailyAssignments["daily5"] = [];
    dailyAssignments["daily6"] = [];
    dailyAssignments["daily7"] = ["daily2"];
    dailyAssignments["daily8"] = ["daily2"];
  } else {
    dailyKeys.forEach((key) => {
      dailyAssignments[key] = [];
    });
  }

  if (featuredKeys.length === 4) {
    featuredAssignments["featured1"] = [];
    featuredAssignments["featured2"] = [];
    featuredAssignments["featured3"] = ["Featured1"];
    featuredAssignments["featured4"] = ["Featured1"];
  } else if (featuredKeys.length === 5) {
    featuredAssignments["featured1"] = [];
    featuredAssignments["featured2"] = ["Featured1"];
    featuredAssignments["featured3"] = ["Featured1"];
    featuredAssignments["featured4"] = ["Featured1"];
    featuredAssignments["featured5"] = [];
  } else if (featuredKeys.length === 6) {
    featuredAssignments["featured1"] = ["Featured1"];
    featuredAssignments["featured2"] = ["Featured1"];
    featuredAssignments["featured3"] = ["Featured2"];
    featuredAssignments["featured4"] = ["Featured2"];
    featuredAssignments["featured5"] = ["Featured3"];
    featuredAssignments["featured6"] = ["Featured3"];
  } else {
    featuredKeys.forEach((key) => {
      featuredAssignments[key] = [];
    });
  }

  const todayAtMidnight = new Date();
  todayAtMidnight.setHours(24, 0, 0, 0);
  const todayOneMinuteBeforeMidnight = new Date(
    todayAtMidnight.getTime() - 60000
  );
  const isoDate = todayOneMinuteBeforeMidnight.toISOString();

  try {
    for (const key in CatalogConfig) {
      const configEntry = CatalogConfig[key];
      if (
        !Array.isArray(configEntry?.itemGrants) ||
        configEntry.itemGrants.length === 0
      )
        continue;

      const CatalogEntry: CatalogEntry = {
        devName: "",
        offerId: "",
        fulfillmentIds: [],
        dailyLimit: -1,
        weeklyLimit: -1,
        monthlyLimit: -1,
        categories: [],
        prices: [
          {
            currencyType: "MtxCurrency",
            currencySubType: "",
            regularPrice: 0,
            finalPrice: 0,
            saleExpiration: "9999-12-02T01:12:00Z",
            basePrice: 0,
          },
        ],
        meta: {
          NewDisplayAssetPath: "",
          SectionId: "Daily",
          TileSize: "Small",
        },
        matchFilter: "",
        filterWeight: 0,
        appStoreId: [],
        requirements: [],
        offerType: "StaticPrice",
        giftInfo: {
          bIsEnabled: true,
          forcedGiftBoxTemplateId: "",
          purchaseRequirements: [],
          giftRecordIds: [],
        },
        refundable: true,
        metaInfo: [
          { key: "SectionId", value: "Daily" },
          { key: "TileSize", value: "Small" },
        ],
        displayAssetPath: "",
        itemGrants: [],
        sortPriority: 0,
        catalogGroupPriority: 0,
      };

      const isDaily = key.toLowerCase().startsWith("daily");
      const storefrontName = isDaily
        ? "BRDailyStorefront"
        : "BRWeeklyStorefront";
      const i = catalog.storefronts.findIndex((p) => p.name === storefrontName);
      if (i === -1) continue;

      if (isDaily) {
        CatalogEntry.sortPriority = -1;
        CatalogEntry.categories = dailyAssignments[key] || [];
      } else {
        CatalogEntry.meta.SectionId = "Featured";
        CatalogEntry.meta.TileSize = "Normal";
        if (CatalogEntry.metaInfo.length > 1) {
          CatalogEntry.metaInfo[0]!.value = "Featured";
          CatalogEntry.metaInfo[1]!.value = "Normal";
        }
        CatalogEntry.categories = featuredAssignments[key] || [];
      }

      for (const itemGrant of configEntry.itemGrants) {
        if (typeof itemGrant !== "string" || itemGrant.length === 0) continue;

        CatalogEntry.requirements.push({
          requirementType: "DenyOnItemOwnership",
          requiredId: itemGrant,
          minQuantity: 1,
        });

        CatalogEntry.itemGrants.push({
          templateId: itemGrant,
          quantity: 1,
        });
      }

      CatalogEntry.prices = [
        {
          currencyType: "MtxCurrency",
          currencySubType: "",
          regularPrice: configEntry.price,
          finalPrice: configEntry.price,
          saleExpiration: isoDate,
          basePrice: configEntry.price,
        },
      ];

      if (CatalogEntry.itemGrants.length > 0) {
        const uniqueIdentifier = crypto
          .createHash("sha1")
          .update(
            `${JSON.stringify(configEntry.itemGrants)}_${configEntry.price}`
          )
          .digest("hex");

        CatalogEntry.devName = uniqueIdentifier;
        CatalogEntry.offerId = uniqueIdentifier;

        const storefront = catalog.storefronts[i];
        if (!storefront) continue;

        storefront.catalogEntries.push(CatalogEntry);
      }
    }
  } catch (err) {
    Logger.Error("Error while getting item shop: ", err);
  }

  return catalog;
}

// Shop for 14.30+
export async function getItemShopV2(): Promise<Catalog> {
  const catalogPath = path.join(
    __dirname,
    "..",
    "..",
    "static",
    "shop",
    "catalog.json"
  );
  const catalogConfigPath = path.join(
    __dirname,
    "..",
    "..",
    "static",
    "shop",
    "catalog_configV2.json"
  );

  const catalog: Catalog = JSON.parse(fs.readFileSync(catalogPath, "utf8"));
  const catalogConfig: CatalogConfig = JSON.parse(
    fs.readFileSync(catalogConfigPath, "utf8")
  );

  const todayAtMidnight = new Date();
  todayAtMidnight.setHours(24, 0, 0, 0);
  const todayOneMinuteBeforeMidnight = new Date(
    todayAtMidnight.getTime() - 60000
  );
  const isoDate = todayOneMinuteBeforeMidnight.toISOString();

  try {
    for (const key in catalogConfig) {
      const configEntry = catalogConfig[key];
      if (
        !Array.isArray(configEntry?.itemGrants) ||
        configEntry.itemGrants.length === 0
      )
        continue;

      const sectionId = configEntry.section || "Featured";
      const isDaily = sectionId.toLowerCase() === "daily";
      const storefrontName = isDaily
        ? "BRDailyStorefront"
        : "BRWeeklyStorefront";
      const storefront = catalog.storefronts.find(
        (p) => p.name === storefrontName
      );
      if (!storefront) continue;

      let tileSize: "Small" | "Normal" = "Normal";
      if (configEntry.itemGrants.length === 1) {
        const templateId = configEntry.itemGrants[0];
        if (
          (templateId!.startsWith("AthenaItemWrap:") &&
            configEntry.section?.toLowerCase() !== "lava") ||
          templateId!.startsWith("AthenaMusicPack:") ||
          templateId!.startsWith("AthenaBackpack:") ||
          templateId!.startsWith("AthenaLoadingScreen:")
        ) {
          tileSize = "Small";
        } else if (
          isDaily &&
          (templateId!.startsWith("AthenaDance:") ||
            templateId!.startsWith("AthenaGlider:"))
        ) {
          tileSize = "Small";
        } else if (
          ["dance"].includes(configEntry.section?.toLowerCase() || "") &&
          templateId!.startsWith("AthenaDance:")
        ) {
          tileSize = "Small";
        } else if (
          [
            "marvel",
            "icon",
            "starwars",
            "gaming",
            "dc",
            "dark",
            "slurp",
            "lebron",
            "mm",
            "summer",
          ].includes(configEntry.section?.toLowerCase() || "") &&
          (templateId!.startsWith("AthenaDance:") ||
            templateId!.startsWith("AthenaGlider:") ||
            templateId!.startsWith("AthenaPickaxe:"))
        ) {
          tileSize = "Small";
        } else if (
          ["shadow", "travis", "ariana", "balvin"].includes(
            configEntry.section?.toLowerCase() || ""
          ) &&
          (templateId!.startsWith("AthenaDance:") ||
            templateId!.startsWith("AthenaPickaxe:"))
        ) {
          tileSize = "Small";
        }
      }

      const itemGrants = configEntry.itemGrants.map((grant) => ({
        templateId: grant,
        quantity: 1,
      }));

      const requirements = configEntry.itemGrants.map((grant) => ({
        requirementType: "DenyOnItemOwnership",
        requiredId: grant,
        minQuantity: 1,
      }));

      const firstGrant = configEntry.itemGrants[0];
      let newDisplayAssetPath = "";
      let displayAssetPath = "";
      if (firstGrant) {
        const [type, assetId] = firstGrant.split(":");
        if (assetId) {
          newDisplayAssetPath = `/Game/Catalog/NewDisplayAssets/DAv2_${assetId}.DAv2_${assetId}`;
          displayAssetPath = `/Game/Catalog/DisplayAssets/DA_Featured_${assetId}.DA_Featured_${assetId}`;
        }
      }

      const uniqueIdentifier = crypto
        .createHash("sha1")
        .update(
          `${JSON.stringify(configEntry.itemGrants)}_${configEntry.price}`
        )
        .digest("hex");

      const catalogEntry: CatalogEntry = {
        devName: uniqueIdentifier,
        offerId: uniqueIdentifier,
        fulfillmentIds: [],
        dailyLimit: -1,
        weeklyLimit: -1,
        monthlyLimit: -1,
        categories: [],
        prices: [
          {
            currencyType: "MtxCurrency",
            currencySubType: "",
            regularPrice: configEntry.price,
            finalPrice: configEntry.price,
            saleExpiration: isoDate,
            basePrice: configEntry.price,
          },
        ],
        meta: {
          SectionId: sectionId,
          TileSize: tileSize,
          NewDisplayAssetPath: newDisplayAssetPath,
        },
        matchFilter: "",
        filterWeight: 0,
        appStoreId: [],
        requirements,
        offerType: "StaticPrice",
        giftInfo: {
          bIsEnabled: true,
          forcedGiftBoxTemplateId: "",
          purchaseRequirements: [],
          giftRecordIds: [],
        },
        refundable: true,
        metaInfo: [
          { key: "NewDisplayAssetPath", value: newDisplayAssetPath },
          { key: "SectionId", value: sectionId },
          { key: "TileSize", value: tileSize },
        ],
        displayAssetPath,
        itemGrants,
        sortPriority: isDaily ? -1 : 0,
        catalogGroupPriority: 0,
      };

      storefront.catalogEntries.push(catalogEntry);
    }
  } catch (err) {
    Logger.Error("Error while getting item shop: ", err);
  }

  return catalog;
}

interface OfferResult {
  name: string;
  offerId: CatalogEntry;
}

export async function getOfferID(
  offerId: string,
  build: number
): Promise<OfferResult | undefined> {
  let catalog;

  if (build >= 14.3) {
    catalog = await getItemShopV2();
  } else {
    catalog = await getItemShop();
  }

  for (const storefront of catalog.storefronts) {
    const findOfferId = storefront.catalogEntries.find(
      (i) => i.offerId === offerId
    );
    if (findOfferId) {
      return {
        name: storefront.name,
        offerId: findOfferId,
      };
    }
  }

  return undefined;
}
