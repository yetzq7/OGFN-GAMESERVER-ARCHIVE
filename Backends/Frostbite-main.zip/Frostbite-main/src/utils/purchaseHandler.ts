import type { Context } from "hono";
import * as functions from "./funcs";
import variantsData from "../../static/shop/variants.json";

export function handleBattlePassPurchase(
  athena: any,
  profile: any,
  profiles: any,
  BattlePass: any,
  offerId: string,
  season: number,
  ApplyProfileChanges: any[],
  MultiUpdate: any[]
) {
  const lootList: any[] = [];
  let EndingTier = athena.stats.attributes.book_level;
  athena.stats.attributes.book_purchased = true;

  const tokenKey = `Token:Athena_S${season}_NoBattleBundleOption_Token`;
  const tokenData = {
    templateId: `Token:athena_s${season}_nobattlebundleoption_token`,
    attributes: {
      max_level_bonus: 0,
      level: 1,
      item_seen: true,
      xp: 0,
      favorite: false,
    },
    quantity: 1,
  };
  profiles.profiles["common_core"].items[tokenKey] = tokenData;
  ApplyProfileChanges.push({
    changeType: "itemAdded",
    itemId: tokenKey,
    item: tokenData,
  });
  lootList.push({
    itemType: tokenData.templateId,
    itemGuid: tokenKey,
    quantity: 1,
  });

  if (BattlePass.battleBundleOfferId === offerId) {
    athena.stats.attributes.book_level += 25;
    athena.stats.attributes.level += 25;
    if (parseInt(process.env.SEASON || "0") >= 11) {
      athena.stats.attributes.level += 25;
      MultiUpdate[0].profileChanges.push({
        changeType: "statModified",
        name: "level",
        value: athena.stats.attributes.level,
      });
    }
    if (athena.stats.attributes.book_level > 100)
      athena.stats.attributes.book_level = 100;
    EndingTier = athena.stats.attributes.book_level;
  }

  for (let i = 0; i < EndingTier; i++) {
    const FreeTier = BattlePass.freeRewards[i] || {};
    const PaidTier = BattlePass.paidRewards[i] || {};

    const processRewardTier = (tier: Record<string, number>) => {
      for (const item in tier) {
        const lowerItem = item.toLowerCase();
        const quantity = tier[item];
        let ItemID: string;

        // Boosts
        if (lowerItem === "token:athenaseasonxpboost") {
          athena.stats.attributes.season_match_boost += quantity;
          MultiUpdate[0].profileChanges.push({
            changeType: "statModified",
            name: "season_match_boost",
            value: athena.stats.attributes.season_match_boost,
          });
        }
        if (lowerItem === "token:athenaseasonfriendxpboost") {
          athena.stats.attributes.season_friend_match_boost += quantity;
          MultiUpdate[0].profileChanges.push({
            changeType: "statModified",
            name: "season_friend_match_boost",
            value: athena.stats.attributes.season_friend_match_boost,
          });
        }

        // Vbucks
        if (lowerItem.startsWith("currency:mtx")) {
          for (const key in profiles.profiles["common_core"].items) {
            const ccItem = profiles.profiles["common_core"].items[key];
            if (ccItem.templateId.toLowerCase() === "currency:mtxpurchased") {
              ccItem.quantity += quantity;
              ApplyProfileChanges.push({
                changeType: "itemQuantityChanged",
                itemId: key,
                quantity: ccItem.quantity,
              });
              lootList.push({
                itemType: ccItem.templateId,
                itemGuid: key,
                quantity,
              });
              break;
            }
          }
        }

        // Banners
        if (lowerItem.startsWith("homebasebanner")) {
          let found = false;
          for (const key in profile.items) {
            if (profile.items[key].templateId.toLowerCase() === lowerItem) {
              profile.items[key].attributes.item_seen = false;
              ApplyProfileChanges.push({
                changeType: "itemAttrChanged",
                itemId: key,
                attributeName: "item_seen",
                attributeValue: false,
              });
              ItemID = key;
              found = true;
              break;
            }
          }
          if (!found) {
            ItemID = functions.MakeID();
            const Item = {
              templateId: item,
              attributes: { item_seen: false },
              quantity: 1,
            };
            profile.items[ItemID] = Item;
            ApplyProfileChanges.push({
              changeType: "itemAdded",
              itemId: ItemID,
              item: Item,
            });
          }
          lootList.push({
            itemType: item,
            itemGuid: functions.MakeID(),
            quantity: 1,
          });
        }

        // Cosmetics
        if (lowerItem.startsWith("athena")) {
          let found = false;
          for (const key in athena.items) {
            if (athena.items[key].templateId.toLowerCase() === lowerItem) {
              athena.items[key].attributes.item_seen = false;
              MultiUpdate[0].profileChanges.push({
                changeType: "itemAttrChanged",
                itemId: key,
                attributeName: "item_seen",
                attributeValue: false,
              });
              ItemID = key;
              found = true;
              break;
            }
          }
          if (!found) {
            ItemID = functions.MakeID();
            const entry = variantsData.find(
              (v: any) => v.id.toLowerCase() === item.toLowerCase()
            );
            const variants = entry?.variants || [];
            const Item = {
              templateId: item,
              attributes: {
                max_level_bonus: 0,
                level: 1,
                item_seen: false,
                xp: 0,
                variants,
                favorite: false,
              },
              quantity,
            };
            athena.items[ItemID] = Item;
            MultiUpdate[0].profileChanges.push({
              changeType: "itemAdded",
              itemId: ItemID,
              item: Item,
            });
          }
          lootList.push({
            itemType: item,
            itemGuid: functions.MakeID(),
            quantity,
          });
        }
      }
    };

    processRewardTier(FreeTier);
    processRewardTier(PaidTier);
  }

  MultiUpdate[0].profileChanges.push({
    changeType: "statModified",
    name: "book_purchased",
    value: true,
  });
  MultiUpdate[0].profileChanges.push({
    changeType: "statModified",
    name: "book_level",
    value: athena.stats.attributes.book_level,
  });
  MultiUpdate[0].profileChanges.push({
    changeType: "statModified",
    name: "level",
    value: athena.stats.attributes.level,
  });

  return lootList;
}

export function handleTierPurchase(
  athena: any,
  profile: any,
  profiles: any,
  BattlePass: any,
  reqBody: any,
  ApplyProfileChanges: any[],
  MultiUpdate: any[]
) {
  const lootList: any[] = [];
  const StartingTier = athena.stats.attributes.book_level;
  const purchaseQuantity = reqBody.purchaseQuantity ?? 1;
  athena.stats.attributes.book_level += purchaseQuantity;

  if (parseFloat(process.env.VERSION || "0") >= 11) {
    athena.stats.attributes.level += purchaseQuantity;
    MultiUpdate[0].profileChanges.push({
      changeType: "statModified",
      name: "level",
      value: athena.stats.attributes.level,
    });
  }

  const EndingTier = athena.stats.attributes.book_level;

  for (let i = StartingTier; i < EndingTier; i++) {
    const FreeTier = BattlePass.freeRewards[i] || {};
    const PaidTier = BattlePass.paidRewards[i] || {};

    const processRewardTier = (tier: Record<string, number>) => {
      for (const item in tier) {
        const lowerItem = item.toLowerCase();
        const quantity = tier[item];
        let ItemID: string;

        // Boosts
        if (lowerItem === "token:athenaseasonxpboost") {
          athena.stats.attributes.season_match_boost += quantity;
          MultiUpdate[0].profileChanges.push({
            changeType: "statModified",
            name: "season_match_boost",
            value: athena.stats.attributes.season_match_boost,
          });
        }
        if (lowerItem === "token:athenaseasonfriendxpboost") {
          athena.stats.attributes.season_friend_match_boost += quantity;
          MultiUpdate[0].profileChanges.push({
            changeType: "statModified",
            name: "season_friend_match_boost",
            value: athena.stats.attributes.season_friend_match_boost,
          });
        }

        // Vbucks
        if (lowerItem.startsWith("currency:mtx")) {
          for (const key in profiles.profiles["common_core"].items) {
            const ccItem = profiles.profiles["common_core"].items[key];
            if (ccItem.templateId.toLowerCase() === "currency:mtxpurchased") {
              ccItem.quantity += quantity;
              ApplyProfileChanges.push({
                changeType: "itemQuantityChanged",
                itemId: key,
                quantity: ccItem.quantity,
              });
              lootList.push({
                itemType: ccItem.templateId,
                itemGuid: key,
                quantity,
              });
              break;
            }
          }
        }

        // Banners
        if (lowerItem.startsWith("homebasebanner")) {
          let found = false;
          for (const key in profile.items) {
            if (profile.items[key].templateId.toLowerCase() === lowerItem) {
              profile.items[key].attributes.item_seen = false;
              ApplyProfileChanges.push({
                changeType: "itemAttrChanged",
                itemId: key,
                attributeName: "item_seen",
                attributeValue: false,
              });
              ItemID = key;
              found = true;
              break;
            }
          }
          if (!found) {
            ItemID = functions.MakeID();
            const Item = {
              templateId: item,
              attributes: { item_seen: false },
              quantity: 1,
            };
            profile.items[ItemID] = Item;
            ApplyProfileChanges.push({
              changeType: "itemAdded",
              itemId: ItemID,
              item: Item,
            });
          }
          lootList.push({
            itemType: item,
            itemGuid: functions.MakeID(),
            quantity: 1,
          });
        }

        // Cosmetics
        if (lowerItem.startsWith("athena")) {
          let found = false;
          for (const key in athena.items) {
            if (athena.items[key].templateId.toLowerCase() === lowerItem) {
              athena.items[key].attributes.item_seen = false;
              MultiUpdate[0].profileChanges.push({
                changeType: "itemAttrChanged",
                itemId: key,
                attributeName: "item_seen",
                attributeValue: false,
              });
              ItemID = key;
              found = true;
              break;
            }
          }
          if (!found) {
            ItemID = functions.MakeID();
            const entry = variantsData.find(
              (v: any) => v.id.toLowerCase() === item.toLowerCase()
            );
            const variants = entry?.variants || [];
            const Item = {
              templateId: item,
              attributes: {
                max_level_bonus: 0,
                level: 1,
                item_seen: false,
                xp: 0,
                variants,
                favorite: false,
              },
              quantity,
            };
            athena.items[ItemID] = Item;
            MultiUpdate[0].profileChanges.push({
              changeType: "itemAdded",
              itemId: ItemID,
              item: Item,
            });
          }
          lootList.push({
            itemType: item,
            itemGuid: functions.MakeID(),
            quantity,
          });
        }
      }
    };

    processRewardTier(FreeTier);
    processRewardTier(PaidTier);
  }

  MultiUpdate[0].profileChanges.push({
    changeType: "statModified",
    name: "book_level",
    value: athena.stats.attributes.book_level,
  });

  return lootList;
}

export function handleCatalogPurchase(
  athena: any,
  findOfferId: any,
  MultiUpdate: any[],
  error: any,
  c: Context
) {
  const lootList: any[] = [];

  for (const value of findOfferId.offerId.itemGrants) {
    const ID = functions.MakeID();

    for (const itemId in athena.items) {
      if (
        value.templateId.toLowerCase() ===
        athena.items[itemId].templateId.toLowerCase()
      ) {
        return error.createError(
          c,
          "errors.com.epicgames.offer.already_owned",
          "You have already bought this item before.",
          [],
          1040,
          undefined,
          400
        );
      }
    }

    const entry = variantsData.find(
      (v: any) => v.id.toLowerCase() === value.templateId.toLowerCase()
    );
    const variants = entry?.variants || [];

    const Item = {
      templateId: value.templateId,
      attributes: { item_seen: false, variants },
      quantity: 1,
    };

    athena.items[ID] = Item;

    MultiUpdate[0].profileChanges.push({
      changeType: "itemAdded",
      itemId: ID,
      item: athena.items[ID],
    });

    lootList.push({
      itemType: Item.templateId,
      itemGuid: ID,
      itemProfile: "athena",
      quantity: 1,
    });
  }

  return lootList;
}
