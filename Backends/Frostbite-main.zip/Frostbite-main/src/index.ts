import { Hono } from "hono";
import { Logger } from "./utils/logger";
import { loadRoutes } from "./utils/funcs";
import { InitDB } from "./database/mongodb";
import * as error from "./utils/error";

const app = new Hono();
const port = Number(process.env.BACKEND_PORT) || 3551;

Logger.Backend(`Backend started listening on port ${port}`);

app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "http://192.168.1.69:3000");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (c.req.method === "OPTIONS") return c.body(null, 204);
  await next();
});

app.get("/", (c) => c.text("Frostbite, Made by Razer."));
app.get("/unknown", (c) => c.json({ error: "Frostbite, Made by Razer." }));
await loadRoutes(app);
await InitDB();

app.use("*", async (c) => {
  return error.createError(
    c,
    "errors.com.frost.common.not_found",
    "Sorry the resource you were trying to find could not be found",
    [],
    1004,
    undefined,
    404
  );
});

Bun.serve({
  fetch: app.fetch,
  port,
});
