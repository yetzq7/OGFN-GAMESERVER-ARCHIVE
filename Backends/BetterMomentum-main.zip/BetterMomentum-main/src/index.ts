import fs from "fs";
import path from 'path';
import https from 'https';
import { dirname } from 'dirname-filename-esm';
import log from './utilities/structs/log.js';
import express from "express";
import mongoose from "mongoose";
import jwt, { JwtPayload } from 'jsonwebtoken';
import rateLimit from "express-rate-limit";
import destr from "destr";
import { client } from './bot/index.js';
import kv from './utilities/kv.js';
import Safety from './utilities/safety.js';
import functions from "./utilities/structs/functions.js";
import error from "./utilities/structs/error.js";
import { version } from "./utilities/cron/update.js";
import serverRegistrationRoutes from "./routes/BetterMomentum_API.js";
import "./utilities/cron/update.js";
import { DateAddHours } from "./routes/auth.js";
import "./model/gameServers.js";
import gameServers from "./model/gameServers.js";

const __dirname = dirname(import.meta);

// SSL
function setupSSL() {
    const sslDir = path.join(__dirname, "../ssl");
    
    const certNames = [
        { cert: 'certificate.crt', key: 'private.key', ca: 'ca_bundle.crt' },
        { cert: 'server.crt', key: 'server.key', ca: 'ca.crt' },
        { cert: 'cert.pem', key: 'key.pem', ca: 'chain.pem' },
        { cert: 'fullchain.pem', key: 'privkey.pem', ca: null },
        { cert: 'ssl.crt', key: 'ssl.key', ca: 'intermediate.crt' }
    ];

    if (!fs.existsSync(sslDir)) {
        log.backend("running HTTP only bc no ssl folder was found..");
        return null;
    }

    for (const certConfig of certNames) {
        const certPath = path.join(sslDir, certConfig.cert);
        const keyPath = path.join(sslDir, certConfig.key);
        const caPath = certConfig.ca ? path.join(sslDir, certConfig.ca) : null;

        if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
            try {
                const sslOptions: https.ServerOptions = {
                    cert: fs.readFileSync(certPath, 'utf8'),
                    key: fs.readFileSync(keyPath, 'utf8')
                };

                if (caPath && fs.existsSync(caPath)) {
                    sslOptions.ca = fs.readFileSync(caPath, 'utf8');
                    log.backend(`SSL certificates loaded with CA bundle: ${certConfig.cert}, ${certConfig.key}, ${certConfig.ca}`);
                } else {
                    log.backend(`SSL certificates loaded: ${certConfig.cert}, ${certConfig.key}`);
                }

                return sslOptions;
            } catch (error) {
                continue;
            }
        }
    }

    log.backend("running HTTP only bc no certificates were found.");
    return null;
}

const iniPath = path.join(__dirname, "../CloudStorage/DefaultGame.ini");
const playlists = process.env.PLAYLIST?.split(",").map(p => p.trim());

if (playlists && playlists.length > 0) {
    let iniContent = fs.existsSync(iniPath) ? fs.readFileSync(iniPath, "utf-8") : "";
    const sectionHeader = "[/Script/FortniteGame.FortGameInstance]";
    let sectionIndex = iniContent.indexOf(sectionHeader);

    if (sectionIndex !== -1) { 
        const beforeSection = iniContent.slice(0, sectionIndex + sectionHeader.length);
        let sectionContent = iniContent.slice(sectionIndex + sectionHeader.length);
        const lines = sectionContent.split("\n");
        const clearIndex = lines.findIndex(line => line.trim() === "!FrontEndPlaylistData=ClearArray");

        if (clearIndex !== -1) {
            let insertIndex = clearIndex + 1;
            while (insertIndex < lines.length && lines[insertIndex].trim().startsWith("+FrontEndPlaylistData=")) {
                lines.splice(insertIndex, 1);
            }

            const newPlaylistLines = playlists.map((playlist, index) =>
                `+FrontEndPlaylistData=(PlaylistName=${playlist}, PlaylistAccess=(bEnabled=True, bIsDefaultPlaylist=${index === 0}, bVisibleWhenDisabled=false, bDisplayAsNew=false, CategoryIndex=0, bDisplayAsLimitedTime=false, DisplayPriority=${index}))`
            );

            lines.splice(clearIndex + 1, 0, ...newPlaylistLines);
            sectionContent = lines.join("\n");
            iniContent = beforeSection + sectionContent;
            fs.writeFileSync(iniPath, iniContent);
            log.backend("Playlists replaced under [/Script/FortniteGame.FortGameInstance] in DefaultGame.ini");
        }
    }
}

const app = express();
const PORT = Safety.env.PORT;

global.kv = kv;
global.safety = Safety;
global.JWT_SECRET = functions.MakeID();
global.safetyEnv = Safety.env;
global.accessTokens = [];
global.refreshTokens = [];
global.clientTokens = [];
global.smartXMPP = false;
global.exchangeCodes = [];

await Safety.airbag();
await client.login(process.env.BOT_TOKEN);

let redisTokens: any;
let tokens: any;

if (Safety.env.USE_REDIS) {
    redisTokens = await kv.get('tokens');
    try {
        tokens = destr(redisTokens);
    } catch (err) {
        await kv.set('tokens', fs.readFileSync(path.join(__dirname, "../tokens.json")).toString());
        log.error("Redis tokens error, resetting tokens.json");
    }
} else {
    tokens = destr(fs.readFileSync(path.join(__dirname, "../tokens.json")).toString());
}

for (let tokenType in tokens) {
    for (let tokenIndex in tokens[tokenType]) {
        let decodedToken: JwtPayload = jwt.decode(tokens[tokenType][tokenIndex].token.replace("eg1~", "")) as JwtPayload;
        if (DateAddHours(new Date(decodedToken.creation_date), decodedToken.hours_expire).getTime() <= new Date().getTime()) {
            tokens[tokenType].splice(Number(tokenIndex), 1);
        }
    }
}

if (Safety.env.USE_REDIS) {
    await kv.set('tokens', JSON.stringify(tokens, null, 2));
} else {
    fs.writeFileSync(path.join(__dirname, "../tokens.json"), JSON.stringify(tokens, null, 2) || "");
}

if (!tokens || !tokens.accessTokens) {
    console.log("No access tokens found, resetting tokens.json");
    await kv.set('tokens', fs.readFileSync(path.join(__dirname, "../tokens.json")).toString());
    tokens = destr(fs.readFileSync(path.join(__dirname, "../tokens.json")).toString());
}

global.accessTokens = tokens.accessTokens;
global.refreshTokens = tokens.refreshTokens;
global.clientTokens = tokens.clientTokens;

mongoose.set("strictQuery", true);

mongoose
    .connect(Safety.env.MONGO_URI)
    .then(() => log.backend("Connected to MongoDB"))
    .catch((error) => console.error("Error connecting to MongoDB: ", error));

(mongoose.connection as any).on("error", (err: Error) => {
    log.error("MongoDB failed to connect. Please make sure MongoDB is installed and running.");
    throw err;
});

async function deleteAllGameServers() {
    try {
        const result = await gameServers.deleteMany({});
        return result;
    } catch (error) {
        console.error('cannot delete gameservers:', error);
        throw error;
    }
}

app.get("/", (req, res) => {
    res.status(200).json({
        status: "ok",
        version: version,
        uptime: process.uptime(),
        memoryUsage: process.memoryUsage(),
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch,
        cpuUsage: process.cpuUsage(),
        environment: process.env.NODE_ENV,
        ssl: !!setupSSL()
    });
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(serverRegistrationRoutes);

const importRoutes = async (dir) => {
    for (const fileName of fs.readdirSync(path.join(__dirname, dir))) {
        if (fileName.includes(".map")) continue;
        try {
            app.use((await import(`file://${__dirname}/${dir}/${fileName}`)).default);
        } catch (error) {
            console.log(fileName, error);
        }
    }
};

await importRoutes("routes");
await importRoutes("api");

const sslOptions = setupSSL();

if (sslOptions) {
    const httpsServer = https.createServer(sslOptions, app);
    httpsServer.listen(PORT, () => {
        log.backend(`Backend is running on Port ${PORT} (SSL)`);
        import("./xmpp/xmpp.js");
    }).on("error", async (err: any) => {
        if (err.code === "EADDRINUSE") {
            log.error(`Port ${PORT} is already in use!\nClosing in 3 seconds...`);
            await functions.sleep(3000);
            process.exit(0);
        } else {
            log.error(`HTTPS Server error: ${err.message}`);
            throw err;
        }
    });
} else {
    app.listen(PORT, () => {
        log.backend(`Backend is running on Port ${PORT} (no SSL)`);
        import("./xmpp/xmpp.js");
    }).on("error", async (err: any) => {
        if (err.code === "EADDRINUSE") {
            log.error(`Port ${PORT} is already in use!\nClosing in 3 seconds...`);
            await functions.sleep(3000);
            process.exit(0);
        } else throw err;
    });
}

const loggedUrls = new Set<string>();

app.use((req, res, next) => {
    const url = req.originalUrl;
    if (!loggedUrls.has(url)) {
        log.debug(`Missing endpoint: ${req.method} ${url} request port ${req.socket.localPort}`);
        error.createError(
            "errors.com.epicgames.common.not_found",
            "Sorry, the resource you are trying to access could not be found",
            undefined, 1004, undefined, 404, res
        );
    }
    next();
});

deleteAllGameServers();
