make sure to look at the Build_instructions.md file and follow it according to the steps.

### Software
1. **Visual Studio 2019/2022** (with C++ development tools)
2. **CMake 3.15+** (https://cmake.org/download/)
3. **vcpkg** (for dependencies)

### Playlist ID's

### Solo Modes
- `playlist_defaultsolo` - Solo
- `playlist_blitz_solo` - Blitz Solo (Fast storm)
- `playlist_solidgold_solo` - Solid Gold Solo (Legendary weapons only)
- `playlist_snipers_solo` - Snipers Solo
- `playlist_impact_solo` - Close Encounters Solo

### Duo Modes
- `playlist_defaultduo` - Duos
- `playlist_blitz_duos` - Blitz Duos
- `playlist_snipers_duos` - Snipers Duos
- `playlist_impact_duos` - Close Encounters Duos
- `playlist_skysupply_duos` - Sky Supply Duos

### Squad Modes
- `playlist_defaultsquad` - Squads
- `playlist_blitz_squad` - Blitz Squads
- `playlist_solidgold_squads` - Solid Gold Squads
- `playlist_highexplosives_squads` - High Explosives Squads
- `playlist_snipers` - Snipers Squads
- `playlist_skysupply_squads` - Sky Supply Squads
- `playlist_impact_squads` - Close Encounters Squads

---

## Competitive/Arena Modes

### Arena (Universal)
- `playlist_showdownalt_solo` - Arena Solo
- `playlist_showdownalt_duos` - Arena Duos
- `playlist_showdownalt_trios` - Arena Trios
- `playlist_showdowntournament_solo` - Tournament Solo

---

## Large Team Modes

### Team Rumble
- `playlist_5x20` - Team Rumble (20v20)

### 50v50
- `playlist_50v50` - 50v50

---

## Limited Time Modes (LTMs)

### Special Modes
- `playlist_playground` - Playground Mode
- `playlist_carmine` - Carmine (Storm King)
- `playlist_fortnite` - The Fortnite
- `playlist_skysupply` - Sky Supply
